# VitaFlow — ডেলিভারি নোট (বাংলা)

## এই প্যাকেজে কী আছে
- Native Android project: Kotlin + Jetpack Compose + Material 3।
- Package/application ID: `com.vitaflow.app`।
- App branding: VitaFlow; AI assistant coordinator: Nova।
- Existing local-first fitness, tasks, meals, hydration, goals, reminders, progress, voice and allow-listed assistant code retained and rebranded.
- Settings-এ বাংলা/English ভাষা পছন্দ Preferences DataStore-এ সংরক্ষিত হয়; navigation ও Settings-এর প্রধান label ভাষা অনুযায়ী বদলায়।
- Custom emerald/teal vector launcher icon, updated app label, Firestore rules, setup documentation, static verifier and test report.

## Android Studio-তে খোলা
1. ZIP extract করো।
2. Android Studio-তে `VitaFlowProject` folder open করো (এখানেই `settings.gradle.kts` আছে)।
3. Android Studio-র stable JDK 17 এবং project-এ নির্ধারিত Android SDK Platform install করো।
4. Gradle Sync সম্পন্ন হতে দাও।
5. Firebase features ব্যবহার করতে নিজের Firebase Console থেকে সঠিক `google-services.json` ডাউনলোড করে `app/google-services.json` হিসেবে রাখো। `google-services.json.example.txt` আসল config নয়।
6. `FIREBASE_SETUP_BN.md` অনুসরণ করো।

## APK
এই প্যাকেজে verified APK নেই, কারণ এই পরিবেশে native build সফলভাবে যাচাই করা যায়নি। Android Studio-তে **Build → Build Bundle(s) / APK(s) → Build APK(s)** ব্যবহার করো।

## ভাষা
Settings-এ বাংলা এবং English নির্বাচন করা যায়; পছন্দ DataStore-এ persist হয়। Navigation ও Settings-এর কিছু প্রধান label বদলায়। প্রতিটি feature screen-এর সব text এখনও সম্পূর্ণ translated নয়; কিছু screen-এ English/Bengali মিশ্র text থাকতে পারে।

## Firebase / cloud / AI
Firebase project configuration, Google provider, signing fingerprints, App Check, Firestore rules deployment এবং Firebase AI Logic setup owner-কে করতে হবে। Cloud implementation-এর পূর্ণ bidirectional restore/conflict resolution এখনও নেই। `Hey Nova` foreground speech-service prototype, screen-off always-on wake-word নয়।

## নিরাপত্তা
- `firebase/firestore.rules` authenticated UID অনুযায়ী `/users/{uid}/...` data isolate করে; Firebase Console-এ rules deploy করে পরীক্ষা করো।
- Private service-account key, keystore password, বা debug App Check token ZIP-এ যোগ করা হয়নি।
- AI output arbitrary Kotlin/code/shell/URL execute করতে পারে না; action registry allow-listed।
- অ্যাপটি medical diagnosis বা clinical nutrition guidance-এর বিকল্প নয়।
