# VitaFlow — Ultimate Native Android Project Source

**Standalone project:** VitaFlow is a new native Android app. It is not derived from or linked to MissionMe.

VitaFlow is a personal-use fitness and daily-routine app built with Kotlin, Jetpack Compose, Material 3, MVVM-style UI/state handling, a local-first repository, Firebase Authentication/Firestore, and Firebase AI Logic for Nova.

## Features implemented in this source package

- **Home dashboard:** current-day hydration, task overview, workouts and shortcuts to feature screens.
- **Daily tasks:** add tasks, mark a unique matching task complete, local persistence and UID-scoped Firestore writes when signed in.
- **Workout:** starter beginner-friendly activity cards, a simple workout timer, custom workout plans and session history.
- **Nutrition:** meal logging with optional user-entered calorie estimates, saved meal plans and deletion confirmations.
- **Hydration:** daily logging, editable hydration target, log history and weekly summaries.
- **Goals:** personal goals with target and completion state, plus a separate daily-focus goal.
- **Reminders:** daily local reminder scheduling, enable/disable/delete, notification channel and rescheduling after device restart/app replacement.
- **Progress:** summaries and weekly water/workout charts based on locally saved app records.
- **Nova AI:** Firebase AI Logic + Gemini Developer API, recent chat history, Bengali/English/Banglish prompt handling, approved app-action registry and a small deterministic offline command router.
- **Voice fallback:** Android SpeechRecognizer for voice input and Android TextToSpeech for spoken output. A foreground-only `Hey Nova` phrase prototype is included; it is not a dedicated on-device wake-word model and does not run while the app is backgrounded/screen-off.
- **Sign-in:** Firebase Authentication with Google Credential Manager.
- **Storage:** app-private local JSON for structured records and Preferences DataStore for settings; Firestore writes are scoped to the signed-in UID.
- **Appearance:** light/dark mode.

## Important scope and verification notes

This ZIP is a broad implementation source package, **not a claim that a production APK has already passed compilation or real-device testing**. The current work environment did not have an Android SDK or a usable Gradle installation, and it could not download dependencies, so no APK could be compiled here. Review `BUILD_STATUS.txt` for exactly what was checked.

Cloud support currently writes local records to the signed-in user's Firestore collections; it is **not a full bidirectional cloud restore/merge system**. Firebase is optional for local tracking, but AI chat and Google sign-in need the real Firebase config and project settings. Cloud synchronization only happens when the app explicitly calls the sync method (such as after signing in) or when records are saved while signed in. Check operation messages and Firebase Console when testing.

The wake-phrase prototype depends on Android's available speech-recognition service. Depending on the phone it may require network access, repeat recognition sessions, use the microphone while enabled and foregrounded, and miss the phrase. It is not equivalent to a low-power, dedicated hotword detector. Use the microphone/chat buttons as reliable fallbacks.

Workout and nutrition content is general information, not medical treatment or a personalized prescription. Calorie values are optional estimates entered by the user. Reminder alarms are inexact Android alarms, so the OS may delay them; notifications also require user permission/settings.

## Open/build in Android Studio

1. Install a current Android Studio version, with **JDK 17** and **Android SDK Platform 36** selected in SDK Manager.
2. Extract the ZIP and open the `VitaFlowProject` folder (the folder that contains `settings.gradle.kts`).
3. Wait for Gradle sync to finish. Gradle and Maven dependencies need an internet connection the first time.
4. Complete the Firebase setup in `FIREBASE_SETUP_BN.md` before testing Nova or Google sign-in.
5. Run the `app` configuration on a device or emulator. Use **Build → Build Bundle(s) / APK(s) → Build APK(s)**, or the terminal command `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).
6. For a successful debug build, Android Studio/Gradle normally places the APK at `app/build/outputs/apk/debug/app-debug.apk`.

The included `gradlew` is a minimal bootstrap launcher that downloads the official Gradle distribution over HTTPS; it is not the complete standard Gradle Wrapper implementation. If Android Studio recommends generating a standard wrapper, use its installed Gradle/IDE tooling or run `gradle wrapper --gradle-version 8.13` in a trusted environment after installing Gradle 8.13.

## Firebase setup

Read `FIREBASE_SETUP_BN.md` for the collection checklist and step-by-step setup. The real Firebase file must be `app/google-services.json`; the `.example.txt` file is only a reminder and is **not** valid configuration.

## Security notes

- There is no Gemini API key embedded in the project. Firebase AI Logic is used rather than a direct API-key-based Gemini REST call.
- Never paste private signing keys, OAuth client secrets, service-account JSON, or debug tokens into chat or commit them to source control.
- The model output is treated as untrusted: only action names present in `ActionRegistry` can execute, and repository methods validate input. Unsupported actions do not run.
- Firestore rules are in `firebase/firestore.rules`; deploy those rules to the **VitaFlow** Firebase project and review them before adding collections.
- Debug builds use Firebase App Check's debug provider. Register the generated debug token privately in Firebase Console. Do not distribute an APK containing an App Check debug token.
- Release builds use Play Integrity App Check, which needs valid Firebase/App Check configuration. For a personal sideload test, start with a locally built debug APK and a registered debug token.

## Package map

```text
app/src/main/java/com/vitaflow/app/
  MainActivity.kt                    Google Credential Manager + Firebase Auth
  VitaFlowApplication.kt               Firebase/App Check bootstrap
  ai/NovaAssistant.kt                 Firebase AI Logic chat coordinator
  ai/ActionRegistry.kt               approved app actions only
  ai/LocalIntentRouter.kt             clear offline command fallbacks
  data/VitaFlowRepository.kt            local-first records and Firestore writes
  data/VitaFlowSettingsStore.kt         Preferences DataStore
  model/VitaFlowModels.kt               serializable record models
  reminders/                          local reminder alarms and notifications
  ui/VitaFlowApp.kt                     screens and Compose state
  ui/VitaFlowTheme.kt                   Material 3 theme
  voice/VoiceController.kt            speech recognition and spoken replies
firebase/firestore.rules              UID-scoped security rules
docs/                                 scope, verification, and collection notes
tools/verify_project.py               offline static source/resource checks
```
