# VitaFlow — scope, architecture ও known limits

## Architecture

- **UI:** Kotlin + Jetpack Compose + Material 3.
- **App state:** screen-level Compose state and `StateFlow` exposed by a local-first repository.
- **Local structured records:** app-private SharedPreferences containing JSON records.
- **Settings:** Preferences DataStore.
- **Cloud:** Firebase Authentication, Firestore writes under `users/{uid}/...`, and Firebase AI Logic (`firebase-ai`).
- **Nova safety boundary:** `NovaAssistant` → `ActionRegistry` → repository validation; the model cannot invoke arbitrary Kotlin or URLs.
- **Voice:** Android SpeechRecognizer → same Nova pipeline/action registry → TextToSpeech. `Hey Nova` is foreground-only.
- **Reminders:** AlarmManager inexact daily alarm → BroadcastReceiver → Android notification.

## Approved AI actions

`CREATE_TASK`, `COMPLETE_TASK`, `LOG_WATER_INTAKE`, `SET_HYDRATION_TARGET`, `SET_DAILY_GOAL`, `ADD_GOAL`, `COMPLETE_GOAL`, `COMPLETE_WORKOUT`, `LOG_MEAL`, `CREATE_MEAL_PLAN`, `CREATE_WORKOUT_PLAN`, `CREATE_REMINDER`, `SET_REMINDER_ENABLED`, `GET_PROGRESS`, `GET_TASKS`, `GET_HYDRATION`, `GET_GOALS`, `GET_REMINDERS`, `GET_MEALS`, `GET_MEAL_PLANS`, `GET_WORKOUT_HISTORY`, `GET_WORKOUT_LIBRARY`, `GET_WORKOUT_PLANS`.

No AI-driven arbitrary file, URL, shell, account, or code execution is implemented. Delete operations are not exposed to Nova; deletions performed from the UI use UI confirmation where shown.

## Firestore layout

- `users/{uid}/tasks/{taskId}`
- `users/{uid}/goals/{goalId}`
- `users/{uid}/mealLogs/{logId}`
- `users/{uid}/mealPlans/{planId}`
- `users/{uid}/workoutPlans/{planId}`
- `users/{uid}/workoutSessions/{sessionId}`
- `users/{uid}/hydrationLogs/{logId}`
- `users/{uid}/reminders/{reminderId}`
- `users/{uid}/profile/summary`

Current Firestore support is UID-scoped writes and local-to-cloud upload; complete cloud download/merge, conflict resolution and multi-device offline sync remain future enhancements.

## Limitations to keep visible

- This package has not passed a real Android Gradle build in this environment; see `../BUILD_STATUS.txt`.
- A valid Firebase project config is unique to the project owner and cannot be generated in the source ZIP.
- Google Sign-In needs Firebase Google provider setup and certificate fingerprints.
- AI calls need Firebase AI Logic and App Check setup.
- Wake phrase detection depends on Android SpeechRecognizer availability, and may require network/speech services; no screen-off always-listening mode is promised.
- Daily reminders use inexact alarms. Android battery restrictions may delay them.
- No medical diagnosis, clinical meal planning, body-measurement goals, or guaranteed calorie accuracy is represented.
