package com.vitaflow.app.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

/** Schedules local daily reminders without requiring the special exact-alarm permission. */
object ReminderScheduler {
    const val EXTRA_ID = "vitaflow_reminder_id"
    const val EXTRA_TITLE = "vitaflow_reminder_title"

    fun schedule(context: Context, reminder: com.vitaflow.app.model.ReminderItem): Boolean {
        cancel(context, reminder.id)
        if (!reminder.enabled) return true
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return false
        val triggerAt = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, reminder.hour)
            set(Calendar.MINUTE, reminder.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis
        val pendingIntent = pendingIntent(context, reminder.id, reminder.title)
        return runCatching {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            true
        }.getOrDefault(false)
    }

    fun cancel(context: Context, id: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val pending = pendingIntent(context, id, "")
        runCatching { alarmManager.cancel(pending); pending.cancel() }
    }

    private fun pendingIntent(context: Context, id: String, title: String): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_TITLE, title)
        }
        val requestCode = (id.hashCode() and 0x7fffffff).coerceAtLeast(1)
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
