package com.vitaflow.app.model

import org.json.JSONObject
import java.util.UUID

data class TaskItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val isDone: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("title", title)
        .put("isDone", isDone)
        .put("createdAt", createdAt)
        .put("completedAt", completedAt ?: JSONObject.NULL)

    companion object {
        fun fromJson(json: JSONObject) = TaskItem(
            id = json.optString("id", UUID.randomUUID().toString()),
            title = json.optString("title", "Untitled task"),
            isDone = json.optBoolean("isDone", false),
            createdAt = json.optLong("createdAt", System.currentTimeMillis()),
            completedAt = if (json.isNull("completedAt")) null else json.optLong("completedAt").takeIf { it > 0L }
        )
    }
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val fromUser: Boolean,
    val isError: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("text", text)
        .put("fromUser", fromUser)
        .put("isError", isError)
        .put("createdAt", createdAt)

    companion object {
        fun fromJson(json: JSONObject) = ChatMessage(
            id = json.optString("id", UUID.randomUUID().toString()),
            text = json.optString("text"),
            fromUser = json.optBoolean("fromUser", false),
            isError = json.optBoolean("isError", false),
            createdAt = json.optLong("createdAt", System.currentTimeMillis())
        )
    }
}

data class MealLogItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val mealType: String = "Snack",
    val calories: Int? = null,
    val note: String = "",
    val loggedAt: Long = System.currentTimeMillis()
) {
    fun toJson() = JSONObject()
        .put("id", id).put("name", name).put("mealType", mealType)
        .put("calories", calories ?: JSONObject.NULL).put("note", note).put("loggedAt", loggedAt)

    companion object {
        fun fromJson(json: JSONObject) = MealLogItem(
            id = json.optString("id", UUID.randomUUID().toString()),
            name = json.optString("name", "Meal"),
            mealType = json.optString("mealType", "Snack"),
            calories = if (json.isNull("calories")) null else json.optInt("calories").takeIf { it in 0..10000 },
            note = json.optString("note", ""),
            loggedAt = json.optLong("loggedAt", System.currentTimeMillis())
        )
    }
}

data class MealPlanItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val breakfast: String,
    val lunch: String,
    val dinner: String,
    val snack: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toJson() = JSONObject().put("id", id).put("title", title).put("breakfast", breakfast)
        .put("lunch", lunch).put("dinner", dinner).put("snack", snack).put("notes", notes).put("createdAt", createdAt)

    companion object {
        fun fromJson(json: JSONObject) = MealPlanItem(
            id = json.optString("id", UUID.randomUUID().toString()),
            title = json.optString("title", "Meal plan"),
            breakfast = json.optString("breakfast", ""),
            lunch = json.optString("lunch", ""),
            dinner = json.optString("dinner", ""),
            snack = json.optString("snack", ""),
            notes = json.optString("notes", ""),
            createdAt = json.optLong("createdAt", System.currentTimeMillis())
        )
    }
}

data class WorkoutPlanItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val focus: String,
    val durationMinutes: Int,
    val exercises: String,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toJson() = JSONObject().put("id", id).put("title", title).put("focus", focus)
        .put("durationMinutes", durationMinutes).put("exercises", exercises).put("createdAt", createdAt)

    companion object {
        fun fromJson(json: JSONObject) = WorkoutPlanItem(
            id = json.optString("id", UUID.randomUUID().toString()),
            title = json.optString("title", "Workout plan"),
            focus = json.optString("focus", "General fitness"),
            durationMinutes = json.optInt("durationMinutes", 15).coerceIn(1, 300),
            exercises = json.optString("exercises", "Comfortable walking and mobility"),
            createdAt = json.optLong("createdAt", System.currentTimeMillis())
        )
    }
}

data class ReminderItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val hour: Int,
    val minute: Int,
    val enabled: Boolean = true,
    val repeatDaily: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) {
    val timeLabel: String get() = "%02d:%02d".format(hour, minute)
    fun toJson() = JSONObject()
        .put("id", id).put("title", title).put("hour", hour).put("minute", minute)
        .put("enabled", enabled).put("repeatDaily", repeatDaily).put("createdAt", createdAt)

    companion object {
        fun fromJson(json: JSONObject) = ReminderItem(
            id = json.optString("id", UUID.randomUUID().toString()),
            title = json.optString("title", "Reminder"),
            hour = json.optInt("hour", 9).coerceIn(0, 23),
            minute = json.optInt("minute", 0).coerceIn(0, 59),
            enabled = json.optBoolean("enabled", true),
            repeatDaily = json.optBoolean("repeatDaily", true),
            createdAt = json.optLong("createdAt", System.currentTimeMillis())
        )
    }
}

data class WorkoutSession(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val durationMinutes: Int,
    val completedAt: Long = System.currentTimeMillis()
) {
    fun toJson() = JSONObject().put("id", id).put("name", name)
        .put("durationMinutes", durationMinutes).put("completedAt", completedAt)

    companion object {
        fun fromJson(json: JSONObject) = WorkoutSession(
            id = json.optString("id", UUID.randomUUID().toString()),
            name = json.optString("name", "Workout"),
            durationMinutes = json.optInt("durationMinutes", 15).coerceIn(1, 300),
            completedAt = json.optLong("completedAt", System.currentTimeMillis())
        )
    }
}

data class GoalItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val targetValue: Int = 1,
    val unit: String = "times",
    val isComplete: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
) {
    fun toJson() = JSONObject().put("id", id).put("title", title)
        .put("targetValue", targetValue).put("unit", unit).put("isComplete", isComplete)
        .put("createdAt", createdAt).put("completedAt", completedAt ?: JSONObject.NULL)

    companion object {
        fun fromJson(json: JSONObject) = GoalItem(
            id = json.optString("id", UUID.randomUUID().toString()),
            title = json.optString("title", "Goal"),
            targetValue = json.optInt("targetValue", 1).coerceIn(1, 100000),
            unit = json.optString("unit", "times"),
            isComplete = json.optBoolean("isComplete", false),
            createdAt = json.optLong("createdAt", System.currentTimeMillis()),
            completedAt = if (json.isNull("completedAt")) null else json.optLong("completedAt").takeIf { it > 0L }
        )
    }
}

data class WaterLogItem(
    val id: String = UUID.randomUUID().toString(),
    val amountMl: Int,
    val loggedAt: Long = System.currentTimeMillis(),
    val date: String
) {
    fun toJson() = JSONObject().put("id", id).put("amountMl", amountMl).put("loggedAt", loggedAt).put("date", date)
    companion object {
        fun fromJson(json: JSONObject) = WaterLogItem(
            id = json.optString("id", UUID.randomUUID().toString()),
            amountMl = json.optInt("amountMl").coerceIn(0, 10000),
            loggedAt = json.optLong("loggedAt", System.currentTimeMillis()),
            date = json.optString("date", "")
        )
    }
}

enum class VitaFlowTab(val title: String) {
    HOME("Home"), WORKOUTS("Workout"), TASKS("Tasks"), NOVA("Nova"), SETTINGS("Settings"),
    NUTRITION("Nutrition"), HYDRATION("Hydration"), GOALS("Goals"), REMINDERS("Reminders"), PROGRESS("Progress")
}

data class ActionResult(val success: Boolean, val message: String)
