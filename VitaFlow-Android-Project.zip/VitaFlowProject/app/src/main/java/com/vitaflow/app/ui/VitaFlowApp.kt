package com.vitaflow.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.app.TimePickerDialog
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillNovaSize
import androidx.compose.foundation.layout.fillNovaWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import com.vitaflow.app.ai.NovaAssistant
import com.vitaflow.app.data.VitaFlowRepository
import com.vitaflow.app.model.ChatMessage
import com.vitaflow.app.model.GoalItem
import com.vitaflow.app.model.MealLogItem
import com.vitaflow.app.model.MealPlanItem
import com.vitaflow.app.model.ReminderItem
import com.vitaflow.app.model.WorkoutSession
import com.vitaflow.app.model.WorkoutPlanItem
import com.vitaflow.app.model.VitaFlowTab
import com.vitaflow.app.model.TaskItem
import com.vitaflow.app.voice.VoiceController
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private class WakeHandlerHolder { var callback: (String) -> Unit = {} }
private enum class VoiceRequest { COMMAND, ENABLE_WAKE }

@Composable
fun VitaFlowApp(
    repository: VitaFlowRepository,
    voiceController: VoiceController,
    onGoogleSignIn: ((String) -> Unit) -> Unit,
    onGoogleSignOut: ((String) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val lifecycleState by lifecycleOwner.lifecycle.currentStateAsState()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val tasks by repository.tasks.collectAsState()
    val waterMl by repository.waterMl.collectAsState()
    val waterTarget by repository.waterTargetMl.collectAsState()
    val waterLogs by repository.waterLogs.collectAsState()
    val workoutsCompleted by repository.workoutsCompleted.collectAsState()
    val dailyGoal by repository.dailyGoal.collectAsState()
    val darkMode by repository.darkMode.collectAsState()
    val language by repository.language.collectAsState()
    val meals by repository.meals.collectAsState()
    val mealPlans by repository.mealPlans.collectAsState()
    val workoutPlans by repository.workoutPlans.collectAsState()
    val reminders by repository.reminders.collectAsState()
    val goals by repository.goals.collectAsState()
    val workoutHistory by repository.workoutHistory.collectAsState()

    var selectedTab by remember { mutableStateOf(VitaFlowTab.HOME) }
    var wakeWordEnabled by remember { mutableStateOf(repository.wakeWordEnabled.value) }
    var showTaskDialog by remember { mutableStateOf(false) }
    var showGoalDialog by remember { mutableStateOf(false) }
    var feedback by remember { mutableStateOf<String?>(null) }
    var isNovaWorking by remember { mutableStateOf(false) }
    val chatMessages = remember {
        val saved = repository.loadChatHistory()
        mutableStateListOf<ChatMessage>().apply {
            if (saved.isEmpty()) add(ChatMessage(text = "হাই! আমি Nova, VitaFlow-র AI assistant। তোমার task, পানি, workout, meal, goal বা reminder নিয়ে আমাকে বলো।", fromUser = false))
            else addAll(saved)
        }
    }
    val wakeHandlerHolder = remember { WakeHandlerHolder() }
    var pendingVoiceRequest by remember { mutableStateOf<VoiceRequest?>(null) }
    var microphonePermissionResult by remember { mutableStateOf<Boolean?>(null) }

    val microphonePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> microphonePermissionResult = granted }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) feedback = "Reminder সেভ হয়েছে, তবে notification দেখাতে Android notification permission দিতে হবে।"
    }

    fun microphoneGranted(): Boolean = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun sendMessage(rawText: String, speakResponse: Boolean = false) {
        val text = rawText.trim()
        if (text.isEmpty() || isNovaWorking) return
        val previous = chatMessages.toList()
        val enabledRemindersBefore = repository.reminders.value.count { it.enabled }
        chatMessages.add(ChatMessage(text = text, fromUser = true))
        repository.saveChatHistory(chatMessages.toList())
        isNovaWorking = true
        scope.launch {
            val answer = try {
                NovaAssistant(repository).reply(text, previous)
            } catch (_: Exception) {
                "Nova-এর সঙ্গে সংযোগ করা যায়নি। আবার চেষ্টা করো।"
            }
            chatMessages.add(ChatMessage(text = answer, fromUser = false))
            repository.saveChatHistory(chatMessages.toList())
            isNovaWorking = false
            val enabledRemindersAfter = repository.reminders.value.count { it.enabled }
            if (enabledRemindersAfter > enabledRemindersBefore && Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (speakResponse) {
                voiceController.speak(answer) {
                    if (wakeWordEnabled && lifecycleState.isAtLeast(Lifecycle.State.RESUMED) && microphoneGranted()) {
                        voiceController.startWakeWord(wakeHandlerHolder.callback)
                    }
                }
            }
        }
    }

    fun performVoiceRequest(request: VoiceRequest) {
        when (request) {
            VoiceRequest.ENABLE_WAKE -> {
                repository.setWakeWordEnabled(true)
                wakeWordEnabled = true
                feedback = "Hey Nova চালু হয়েছে। অ্যাপ সামনে খোলা থাকলেই wake phrase শোনা হবে।"
            }
            VoiceRequest.COMMAND -> {
                voiceController.listenOnce(
                    onResult = { recognized -> sendMessage(recognized, speakResponse = true) },
                    onError = { error -> feedback = error }
                )
            }
        }
    }

    fun requestVoice(request: VoiceRequest) {
        if (microphoneGranted()) {
            performVoiceRequest(request)
        } else {
            pendingVoiceRequest = request
            microphonePermissionResult = null
            microphonePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(microphonePermissionResult) {
        val result = microphonePermissionResult
        if (result != null) {
            if (result) pendingVoiceRequest?.let { performVoiceRequest(it) }
            else feedback = "ভয়েস ব্যবহার করতে মাইক্রোফোন permission দরকার।"
            pendingVoiceRequest = null
            microphonePermissionResult = null
        }
    }

    wakeHandlerHolder.callback = { command ->
        selectedTab = VitaFlowTab.NOVA
        if (command.isNotBlank()) sendMessage(command, speakResponse = true)
        else requestVoice(VoiceRequest.COMMAND)
    }

    LaunchedEffect(wakeWordEnabled, lifecycleState) {
        if (wakeWordEnabled && lifecycleState.isAtLeast(Lifecycle.State.RESUMED) && microphoneGranted()) {
            voiceController.startWakeWord(wakeHandlerHolder.callback)
        } else {
            voiceController.stopWakeWord()
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) voiceController.stopWakeWord()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            voiceController.stopWakeWord()
        }
    }

    LaunchedEffect(feedback) {
        feedback?.let {
            snackbarHostState.showSnackbar(it)
            feedback = null
        }
    }

    VitaFlowTheme(darkTheme = darkMode) {
        Scaffold(
            modifier = Modifier.fillNovaSize(),
            contentWindowInsets = WindowInsets.navigationBars,
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    listOf(VitaFlowTab.HOME, VitaFlowTab.WORKOUTS, VitaFlowTab.TASKS, VitaFlowTab.NOVA, VitaFlowTab.SETTINGS).forEach { tab ->
                        val icon = when (tab) {
                            VitaFlowTab.HOME -> Icons.Default.Home
                            VitaFlowTab.WORKOUTS -> Icons.Default.FitnessCenter
                            VitaFlowTab.TASKS -> Icons.Default.CheckCircle
                            VitaFlowTab.NOVA -> Icons.Default.Chat
                            VitaFlowTab.SETTINGS -> Icons.Default.Settings
                            else -> Icons.Default.Home
                        }
                        NavigationBarItem(
                            selected = selectedTab == tab || (tab == VitaFlowTab.HOME && selectedTab in listOf(VitaFlowTab.NUTRITION, VitaFlowTab.HYDRATION, VitaFlowTab.GOALS, VitaFlowTab.REMINDERS, VitaFlowTab.PROGRESS)),
                            onClick = { selectedTab = tab },
                            icon = { Icon(icon, contentDescription = tab.title) },
                            label = { Text(
                                when (tab) {
                                    VitaFlowTab.HOME -> if (language == "bn") "হোম" else "Home"
                                    VitaFlowTab.WORKOUTS -> if (language == "bn") "ওয়ার্কআউট" else "Workout"
                                    VitaFlowTab.TASKS -> if (language == "bn") "কাজ" else "Tasks"
                                    VitaFlowTab.NOVA -> if (language == "bn") "নোভা" else "Nova"
                                    VitaFlowTab.SETTINGS -> if (language == "bn") "সেটিংস" else "Settings"
                                    else -> tab.title
                                }, fontSize = 11.sp
                            ) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillNovaSize().padding(padding)) {
                when (selectedTab) {
                    VitaFlowTab.HOME -> DashboardScreen(
                        tasks = tasks,
                        waterMl = waterMl,
                        waterTarget = waterTarget,
                        workoutsCompleted = workoutsCompleted,
                        dailyGoal = dailyGoal,
                        onAddWater = { feedback = repository.addWater(250).message },
                        onAddTask = { showTaskDialog = true },
                        onCompleteTask = { task -> feedback = repository.completeTask(task.id).message },
                        onOpenWorkouts = { selectedTab = VitaFlowTab.WORKOUTS },
                        onOpenNova = { selectedTab = VitaFlowTab.NOVA },
                        onOpenModule = { selectedTab = it }
                    )
                    VitaFlowTab.WORKOUTS -> WorkoutsScreen(
                        workoutsCompleted = workoutsCompleted,
                        workoutHistory = workoutHistory,
                        workoutPlans = workoutPlans,
                        onCompleteWorkout = { name, minutes -> feedback = repository.completeWorkout(name, minutes).message },
                        onAddWorkoutPlan = { title, focus, minutes, exercises -> feedback = repository.addWorkoutPlan(title, focus, minutes, exercises).message },
                        onDeleteWorkoutPlan = { plan -> feedback = repository.deleteWorkoutPlan(plan.id).message }
                    )
                    VitaFlowTab.TASKS -> TasksScreen(
                        tasks = tasks,
                        dailyGoal = dailyGoal,
                        onAddTask = { showTaskDialog = true },
                        onCompleteTask = { task -> feedback = repository.completeTask(task.id).message },
                        onEditGoal = { showGoalDialog = true }
                    )
                    VitaFlowTab.NUTRITION -> NutritionScreen(
                        meals = meals,
                        mealPlans = mealPlans,
                        onAddMeal = { name, type, calories, note -> feedback = repository.addMeal(name, type, calories, note).message },
                        onDeleteMeal = { id -> feedback = repository.deleteMeal(id).message },
                        onAddMealPlan = { title, breakfast, lunch, dinner, snack, notes -> feedback = repository.addMealPlan(title, breakfast, lunch, dinner, snack, notes).message },
                        onDeleteMealPlan = { plan -> feedback = repository.deleteMealPlan(plan.id).message }
                    )
                    VitaFlowTab.HYDRATION -> HydrationScreen(
                        waterMl = waterMl,
                        targetMl = waterTarget,
                        logs = waterLogs,
                        onAddWater = { amount -> feedback = repository.addWater(amount).message },
                        onSetTarget = { target -> feedback = repository.setWaterTarget(target).message }
                    )
                    VitaFlowTab.GOALS -> GoalsScreen(
                        goals = goals,
                        onAddGoal = { title, target, unit -> feedback = repository.addGoal(title, target, unit).message },
                        onCompleteGoal = { goal -> feedback = repository.completeGoal(goal.id).message }
                    )
                    VitaFlowTab.REMINDERS -> RemindersScreen(
                        reminders = reminders,
                        onCreateReminder = { title, hour, minute ->
                            feedback = repository.addReminder(title, hour, minute).message
                            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        },
                        onToggleReminder = { reminder, enabled -> feedback = repository.toggleReminder(reminder.id, enabled).message },
                        onDeleteReminder = { reminder -> feedback = repository.deleteReminder(reminder.id).message }
                    )
                    VitaFlowTab.PROGRESS -> ProgressScreen(
                        tasks = tasks,
                        waterMl = waterMl,
                        waterTarget = waterTarget,
                        workoutsCompleted = workoutsCompleted,
                        meals = meals,
                        goals = goals,
                        waterTotals = repository.dayWaterTotals(),
                        workoutTotals = repository.dayWorkoutTotals()
                    )
                    VitaFlowTab.NOVA -> NovaScreen(
                        messages = chatMessages,
                        isWorking = isNovaWorking,
                        onSend = { sendMessage(it) },
                        onMic = { requestVoice(VoiceRequest.COMMAND) },
                        onSuggestedPrompt = { sendMessage(it) }
                    )
                    VitaFlowTab.SETTINGS -> SettingsScreen(
                        repository = repository,
                        wakeWordEnabled = wakeWordEnabled,
                        darkMode = darkMode,
                        language = language,
                        onLanguageChange = { repository.setLanguage(it) },
                        onWakeWordChange = { enabled ->
                            if (enabled) requestVoice(VoiceRequest.ENABLE_WAKE)
                            else {
                                repository.setWakeWordEnabled(false)
                                wakeWordEnabled = false
                                feedback = "Hey Nova বন্ধ করা হয়েছে।"
                            }
                        },
                        onDarkModeChange = { repository.setDarkMode(it) },
                        onGoogleSignIn = { onFinished -> onGoogleSignIn { message ->
                            repository.syncLocalDataToCloud()
                            feedback = message
                            onFinished(message)
                        } },
                        onGoogleSignOut = { onFinished -> onGoogleSignOut { message ->
                            feedback = message
                            onFinished(message)
                        } },
                        onMessage = { feedback = it }
                    )
                }
            }
        }
    }

    if (showTaskDialog) {
        AddTaskDialog(
            onDismiss = { showTaskDialog = false },
            onCreate = { title -> feedback = repository.addTask(title).message; showTaskDialog = false }
        )
    }
    if (showGoalDialog) {
        EditGoalDialog(
            currentGoal = dailyGoal,
            onDismiss = { showGoalDialog = false },
            onSave = { goal -> feedback = repository.setDailyGoal(goal).message; showGoalDialog = false }
        )
    }
}

@Composable
private fun DashboardScreen(
    tasks: List<TaskItem>,
    waterMl: Int,
    waterTarget: Int,
    workoutsCompleted: Int,
    dailyGoal: String,
    onAddWater: () -> Unit,
    onAddTask: () -> Unit,
    onCompleteTask: (TaskItem) -> Unit,
    onOpenWorkouts: () -> Unit,
    onOpenNova: () -> Unit,
    onOpenModule: (VitaFlowTab) -> Unit
) {
    val completed = tasks.count { it.isDone }
    val pending = tasks.filterNot { it.isDone }.take(3)
    LazyColumn(
        modifier = Modifier.fillNovaSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 18.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(Modifier.fillNovaWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("VITAFLOW", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black, letterSpacing = 2.sp, fontSize = 13.sp)
                    Text("Small steps. Strong habits.", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.tertiary), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Bolt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(25.dp))
                }
            }
        }
        item {
            Card(
                modifier = Modifier.fillNovaWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF153F2D))
            ) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), color = Color(0xFFCDE4D3), fontSize = 12.sp)
                    Text("Make today\ncount.", color = Color.White, fontSize = 32.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold)
                    Text("আজকের লক্ষ্য: $dailyGoal", color = Color(0xFFE1F0E5), style = MaterialTheme.typography.bodyMedium)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("$completed/${tasks.size} tasks", color = Color.White, fontWeight = FontWeight.SemiBold)
                            LinearProgressIndicator(
                                progress = { if (tasks.isEmpty()) 0f else completed.toFloat() / tasks.size.toFloat() },
                                modifier = Modifier.fillNovaWidth().padding(top = 7.dp).height(6.dp).clip(CircleShape),
                                color = Color(0xFFB8F36B),
                                trackColor = Color(0xFF315844)
                            )
                        }
                        Button(onClick = onOpenNova, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB8F36B), contentColor = Color(0xFF153F2D))) {
                            Icon(Icons.Default.Chat, null, Modifier.size(17.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Ask Nova")
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(modifier = Modifier.weight(1f), icon = Icons.Default.WaterDrop, label = "Water today", value = "${waterMl} ml", detail = "Target ${waterTarget} ml")
                MetricCard(modifier = Modifier.weight(1f), icon = Icons.Default.FitnessCenter, label = "Workouts", value = workoutsCompleted.toString(), detail = "Sessions completed")
            }
        }
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillNovaWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.fillNovaWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Hydration", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Keep a steady pace through the day", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("${(waterMl * 100 / waterTarget.coerceAtLeast(1)).coerceAtMost(100)}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(
                        progress = { (waterMl.toFloat() / waterTarget.coerceAtLeast(1)).coerceIn(0f, 1f) },
                        modifier = Modifier.fillNovaWidth().height(8.dp).clip(CircleShape)
                    )
                    Row(Modifier.fillNovaWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${(waterTarget - waterMl).coerceAtLeast(0)} ml to go", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = onAddWater) {
                            Icon(Icons.Default.Add, null, Modifier.size(17.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("250 ml")
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillNovaWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Your next tasks", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                TextButton(onClick = onAddTask) { Icon(Icons.Default.Add, null, Modifier.size(17.dp)); Text("Add") }
            }
        }
        if (pending.isEmpty()) {
            item { EmptyState(title = "Nothing pending", subtitle = "দারুণ! নতুন একটি task যোগ করে এগিয়ে যাও।", action = "Add a task", onAction = onAddTask) }
        } else {
            items(pending, key = { it.id }) { task -> TaskRow(task = task, onComplete = { onCompleteTask(task) }) }
        }
        item {
            Text("Your tools", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillNovaWidth()) {
                    OutlinedButton(onClick = { onOpenModule(VitaFlowTab.NUTRITION) }, modifier = Modifier.weight(1f)) { Text("Nutrition") }
                    OutlinedButton(onClick = { onOpenModule(VitaFlowTab.HYDRATION) }, modifier = Modifier.weight(1f)) { Text("Hydration") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillNovaWidth()) {
                    OutlinedButton(onClick = { onOpenModule(VitaFlowTab.GOALS) }, modifier = Modifier.weight(1f)) { Text("Goals") }
                    OutlinedButton(onClick = { onOpenModule(VitaFlowTab.REMINDERS) }, modifier = Modifier.weight(1f)) { Text("Reminders") }
                }
                OutlinedButton(onClick = { onOpenModule(VitaFlowTab.PROGRESS) }, modifier = Modifier.fillNovaWidth()) { Text("Progress & analytics") }
            }
        }
        item {
            OutlinedButton(onClick = onOpenWorkouts, modifier = Modifier.fillNovaWidth(), shape = RoundedCornerShape(18.dp)) {
                Icon(Icons.Default.FitnessCenter, null)
                Spacer(Modifier.width(8.dp))
                Text("Explore workouts")
            }
        }
    }
}

@Composable
private fun MetricCard(
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    detail: String
) {
    Card(modifier = modifier, shape = RoundedCornerShape(23.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.tertiary), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            }
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun TasksScreen(
    tasks: List<TaskItem>,
    dailyGoal: String,
    onAddTask: () -> Unit,
    onCompleteTask: (TaskItem) -> Unit,
    onEditGoal: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillNovaSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeading(title = "Daily tasks", subtitle = "Build consistency one action at a time.") }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiary)) {
                Row(Modifier.fillNovaWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("TODAY'S FOCUS", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Text(dailyGoal, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    }
                    TextButton(onClick = onEditGoal) { Text("Edit") }
                }
            }
        }
        item {
            Row(Modifier.fillNovaWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Task list", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Button(onClick = onAddTask) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("New task") }
            }
        }
        if (tasks.isEmpty()) item { EmptyState("Start with one task", "তোমার আজকের ছোট একটি কাজ লিখে রাখো।", "Create task", onAddTask) }
        items(tasks, key = { it.id }) { task -> TaskRow(task, onComplete = { onCompleteTask(task) }) }
    }
}

@Composable
private fun WorkoutsScreen(
    workoutsCompleted: Int,
    workoutHistory: List<WorkoutSession>,
    workoutPlans: List<WorkoutPlanItem>,
    onCompleteWorkout: (String, Int) -> Unit,
    onAddWorkoutPlan: (String, String, Int, String) -> Unit,
    onDeleteWorkoutPlan: (WorkoutPlanItem) -> Unit
) {
    data class Routine(val name: String, val durationMinutes: Int, val level: String, val description: String)
    val routines = listOf(
        Routine("Full-body basics", 18, "Beginner-friendly", "A balanced starter session with controlled, comfortable movements."),
        Routine("Mobility reset", 9, "Gentle", "An easy mobility break. Keep movements pain-free and unhurried."),
        Routine("Cardio walk", 20, "Adjustable", "Walk at a comfortable, conversational pace and adapt the time to your day.")
    )
    var activeName by remember { mutableStateOf<String?>(null) }
    var plannedMinutes by remember { mutableStateOf(0) }
    var secondsLeft by remember { mutableStateOf(0) }
    var timerRunning by remember { mutableStateOf(false) }
    var showPlanDialog by remember { mutableStateOf(false) }
    var planToDelete by remember { mutableStateOf<WorkoutPlanItem?>(null) }

    LaunchedEffect(activeName, timerRunning) {
        while (timerRunning && activeName != null && secondsLeft > 0) {
            delay(1000L)
            secondsLeft = (secondsLeft - 1).coerceAtLeast(0)
        }
        if (timerRunning && activeName != null && secondsLeft == 0) {
            val finishedName = activeName ?: return@LaunchedEffect
            timerRunning = false
            activeName = null
            onCompleteWorkout(finishedName, plannedMinutes.coerceAtLeast(1))
        }
    }

    LazyColumn(
        modifier = Modifier.fillNovaSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item { ScreenHeading("Workout library", "Choose a routine that fits your energy today.") }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF153F2D))) {
                Row(Modifier.fillNovaWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("COMPLETED SESSIONS", color = Color(0xFFBFE1C8), style = MaterialTheme.typography.labelSmall)
                        Text(workoutsCompleted.toString(), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    }
                    Icon(Icons.Default.FitnessCenter, null, tint = Color(0xFFB8F36B), modifier = Modifier.size(34.dp))
                }
            }
        }
        if (activeName != null) {
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiary)) {
                    Column(Modifier.fillNovaWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Workout timer", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(activeName.orEmpty(), style = MaterialTheme.typography.titleMedium)
                        Text("%02d:%02d".format(secondsLeft / 60, secondsLeft % 60), style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { timerRunning = !timerRunning }, modifier = Modifier.weight(1f)) { Text(if (timerRunning) "Pause" else "Resume") }
                            OutlinedButton(onClick = {
                                val name = activeName.orEmpty()
                                val elapsed = ((plannedMinutes * 60 - secondsLeft) / 60).coerceAtLeast(1)
                                timerRunning = false
                                activeName = null
                                onCompleteWorkout(name, elapsed)
                            }, modifier = Modifier.weight(1f)) { Text("Finish & save") }
                        }
                        TextButton(onClick = { timerRunning = false; activeName = null }) { Text("Cancel timer") }
                    }
                }
            }
        }
        items(routines) { routine ->
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillNovaWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.tertiary), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.FitnessCenter, null, tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(routine.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("${routine.durationMinutes} min · ${routine.level}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Text(routine.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(
                        enabled = activeName == null,
                        onClick = { plannedMinutes = routine.durationMinutes; secondsLeft = routine.durationMinutes * 60; activeName = routine.name; timerRunning = true },
                        modifier = Modifier.fillNovaWidth()
                    ) { Text("Start ${routine.durationMinutes}-min timer") }
                }
            }
        }
        item {
            Row(Modifier.fillNovaWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("My workout plans", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                TextButton(onClick = { showPlanDialog = true }) { Icon(Icons.Default.Add, null); Text("Create") }
            }
        }
        if (workoutPlans.isEmpty()) item { Text("Save a custom plan to keep your routine here.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(workoutPlans, key = { it.id }) { plan ->
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillNovaWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(plan.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("${plan.focus} · ${plan.durationMinutes} min", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(plan.exercises, style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { onCompleteWorkout(plan.title, plan.durationMinutes) }, modifier = Modifier.weight(1f)) { Text("Log completed") }
                        TextButton(onClick = { planToDelete = plan }) { Text("Delete") }
                    }
                }
            }
        }
        item {
            Text("Exercise library", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "Bodyweight squat" to "Move within a comfortable range; keep the movement controlled.",
                    "Wall push-up" to "Keep your body aligned and choose a wall distance that feels manageable.",
                    "Glute bridge" to "Raise hips gently without arching your lower back.",
                    "Bird dog" to "Move opposite arm and leg slowly, keeping your torso steady.",
                    "March in place" to "Choose an easy pace and hold support if needed.",
                    "Gentle shoulder circles" to "Use small, comfortable circles without forcing the range."
                ).forEach { (name, cues) ->
                    Row(Modifier.fillNovaWidth().clip(RoundedCornerShape(15.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FitnessCenter, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(9.dp))
                        Column {
                            Text(name, fontWeight = FontWeight.SemiBold)
                            Text(cues, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item {
            Text("Recent sessions", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (workoutHistory.isEmpty()) {
                Text("Completed sessions will appear here.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    workoutHistory.takeLast(6).reversed().forEach { session ->
                        Row(Modifier.fillNovaWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(session.name, fontWeight = FontWeight.SemiBold)
                                Text("${session.durationMinutes} min · ${SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(session.completedAt))}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
        item { Text("Use a comfortable level and stop if you feel pain, dizziness, or unusual discomfort.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
    if (showPlanDialog) AddWorkoutPlanDialog(onDismiss = { showPlanDialog = false }, onCreate = { title, focus, minutes, exercises -> onAddWorkoutPlan(title, focus, minutes, exercises); showPlanDialog = false })
    planToDelete?.let { plan ->
        AlertDialog(
            onDismissRequest = { planToDelete = null },
            title = { Text("Delete workout plan?") },
            text = { Text("Remove “${plan.title}” from your saved plans?") },
            confirmButton = { TextButton(onClick = { onDeleteWorkoutPlan(plan); planToDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { planToDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun AddWorkoutPlanDialog(onDismiss: () -> Unit, onCreate: (String, String, Int, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var focus by remember { mutableStateOf("General fitness") }
    var minutes by remember { mutableStateOf("15") }
    var exercises by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create workout plan") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Plan name") }, singleLine = true)
                OutlinedTextField(focus, { focus = it }, label = { Text("Focus") }, singleLine = true)
                OutlinedTextField(minutes, { value -> minutes = value.filter { it.isDigit() }.take(3) }, label = { Text("Duration in minutes") }, singleLine = true)
                OutlinedTextField(exercises, { exercises = it }, label = { Text("Exercises or activities") }, minLines = 2, maxLines = 5)
            }
        },
        confirmButton = { TextButton(onClick = { minutes.toIntOrNull()?.let { onCreate(title, focus, it, exercises) } }, enabled = title.isNotBlank() && exercises.isNotBlank() && minutes.toIntOrNull()?.let { it in 1..300 } == true) { Text("Save plan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun NutritionScreen(
    meals: List<MealLogItem>,
    mealPlans: List<MealPlanItem>,
    onAddMeal: (String, String, Int?, String) -> Unit,
    onDeleteMeal: (String) -> Unit,
    onAddMealPlan: (String, String, String, String, String, String) -> Unit,
    onDeleteMealPlan: (MealPlanItem) -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }
    var showPlanDialog by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<MealLogItem?>(null) }
    var planToDelete by remember { mutableStateOf<MealPlanItem?>(null) }
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val todayMeals = meals.filter { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it.loggedAt)) == today }
    val knownCalories = todayMeals.mapNotNull { it.calories }.sum()
    LazyColumn(Modifier.fillNovaSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenHeading("Nutrition", "Log meals and keep a simple record of your day.") }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiary)) {
                Column(Modifier.fillNovaWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("MEALS LOGGED TODAY", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(todayMeals.size.toString(), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text(if (todayMeals.any { it.calories != null }) "User-entered estimate: about $knownCalories kcal" else "No calorie estimate entered today", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Row(Modifier.fillNovaWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Saved meal plans", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                TextButton(onClick = { showPlanDialog = true }) { Icon(Icons.Default.Add, null); Text("Create") }
            }
        }
        if (mealPlans.isEmpty()) item { Text("Save flexible meal ideas for breakfast, lunch and dinner. These are not medical diet prescriptions.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }
        items(mealPlans, key = { it.id }) { plan ->
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillNovaWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(plan.title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { planToDelete = plan }) { Text("Delete") }
                    }
                    Text("Breakfast: ${plan.breakfast}", style = MaterialTheme.typography.bodyMedium)
                    Text("Lunch: ${plan.lunch}", style = MaterialTheme.typography.bodyMedium)
                    Text("Dinner: ${plan.dinner}", style = MaterialTheme.typography.bodyMedium)
                    if (plan.snack.isNotBlank()) Text("Snack: ${plan.snack}", style = MaterialTheme.typography.bodyMedium)
                    if (plan.notes.isNotBlank()) Text(plan.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { Button(onClick = { showAdd = true }, modifier = Modifier.fillNovaWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(7.dp)); Text("Log a meal") } }
        item { Text("Meal history", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        if (meals.isEmpty()) item { EmptyState("Nothing logged yet", "Add breakfast, lunch, dinner or a snack to keep a record.", "Log first meal", { showAdd = true }) }
        items(meals.take(50), key = { it.id }) { meal ->
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(Modifier.fillNovaWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(meal.name, fontWeight = FontWeight.Bold)
                        Text("${meal.mealType} · ${SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(meal.loggedAt))}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (meal.calories != null) Text("Approx. ${meal.calories} kcal · user-entered", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (meal.note.isNotBlank()) Text(meal.note, style = MaterialTheme.typography.bodySmall)
                    }
                    TextButton(onClick = { pendingDelete = meal }) { Text("Delete") }
                }
            }
        }
        item { Text("Nutrition values vary by portion and preparation. VitaFlow does not calculate clinical nutrition values or prescribe a diet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
    if (showAdd) AddMealDialog(onDismiss = { showAdd = false }, onCreate = { name, type, calories, note -> onAddMeal(name, type, calories, note); showAdd = false })
    pendingDelete?.let { meal ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete meal log?") },
            text = { Text("Remove the saved entry for “${meal.name}”?") },
            confirmButton = { TextButton(onClick = { onDeleteMeal(meal.id); pendingDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancel") } }
        )
    }
    if (showPlanDialog) AddMealPlanDialog(onDismiss = { showPlanDialog = false }, onCreate = { title, breakfast, lunch, dinner, snack, notes -> onAddMealPlan(title, breakfast, lunch, dinner, snack, notes); showPlanDialog = false })
    planToDelete?.let { plan ->
        AlertDialog(
            onDismissRequest = { planToDelete = null },
            title = { Text("Delete meal plan?") },
            text = { Text("Remove “${plan.title}” from your saved plans?") },
            confirmButton = { TextButton(onClick = { onDeleteMealPlan(plan); planToDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { planToDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun AddMealPlanDialog(onDismiss: () -> Unit, onCreate: (String, String, String, String, String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var breakfast by remember { mutableStateOf("") }
    var lunch by remember { mutableStateOf("") }
    var dinner by remember { mutableStateOf("") }
    var snack by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create meal plan") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Plan name") }, singleLine = true)
                OutlinedTextField(breakfast, { breakfast = it }, label = { Text("Breakfast idea") }, minLines = 1, maxLines = 2)
                OutlinedTextField(lunch, { lunch = it }, label = { Text("Lunch idea") }, minLines = 1, maxLines = 2)
                OutlinedTextField(dinner, { dinner = it }, label = { Text("Dinner idea") }, minLines = 1, maxLines = 2)
                OutlinedTextField(snack, { snack = it }, label = { Text("Snack (optional)") }, singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("Notes (optional)") }, minLines = 1, maxLines = 2)
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(title, breakfast, lunch, dinner, snack, notes) }, enabled = title.isNotBlank() && breakfast.isNotBlank() && lunch.isNotBlank() && dinner.isNotBlank()) { Text("Save plan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun AddMealDialog(onDismiss: () -> Unit, onCreate: (String, String, Int?, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Snack") }
    var calories by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log a meal") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Food or meal") }, singleLine = true)
                OutlinedTextField(type, { type = it }, label = { Text("Meal type") }, singleLine = true, supportingText = { Text("Breakfast, Lunch, Dinner or Snack") })
                OutlinedTextField(calories, { value -> calories = value.filter { it.isDigit() }.take(5) }, label = { Text("Calories (optional)") }, singleLine = true, supportingText = { Text("Only enter a value you already know; it is an estimate.") })
                OutlinedTextField(note, { note = it }, label = { Text("Note (optional)") }, maxLines = 2)
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onCreate(name, type, calories.toIntOrNull(), note) }, enabled = name.isNotBlank() && (calories.isBlank() || calories.toIntOrNull()?.let { it in 0..10000 } == true)) { Text("Save meal") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun HydrationScreen(
    waterMl: Int,
    targetMl: Int,
    logs: List<com.vitaflow.app.model.WaterLogItem>,
    onAddWater: (Int) -> Unit,
    onSetTarget: (Int) -> Unit
) {
    var showTarget by remember { mutableStateOf(false) }
    var targetInput by remember(targetMl) { mutableStateOf(targetMl.toString()) }
    val percentage = (waterMl.toFloat() / targetMl.coerceAtLeast(1)).coerceIn(0f, 1f)
    LazyColumn(Modifier.fillNovaSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenHeading("Hydration", "Track water at your own pace throughout the day.") }
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiary)) {
                Column(Modifier.fillNovaWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("TODAY", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("$waterMl ml", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    LinearProgressIndicator(progress = { percentage }, modifier = Modifier.fillNovaWidth().height(9.dp).clip(CircleShape))
                    Text("Target $targetMl ml · ${(percentage * 100).toInt()}%", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { showTarget = true }) { Text("Change daily target") }
                }
            }
        }
        item { Text("Log water", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillNovaWidth()) {
                Button(onClick = { onAddWater(150) }, modifier = Modifier.weight(1f)) { Text("+150 ml") }
                Button(onClick = { onAddWater(250) }, modifier = Modifier.weight(1f)) { Text("+250 ml") }
                OutlinedButton(onClick = { onAddWater(500) }, modifier = Modifier.weight(1f)) { Text("+500 ml") }
            }
        }
        item { Text("Recent entries", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        if (logs.none { it.date == SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }) item { Text("No water entries yet today.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(logs.filter { it.date == SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }.takeLast(20).reversed(), key = { it.id }) { log ->
            Row(Modifier.fillNovaWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.WaterDrop, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("${log.amountMl} ml", fontWeight = FontWeight.SemiBold)
                    Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(log.loggedAt)), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
    if (showTarget) AlertDialog(
        onDismissRequest = { showTarget = false },
        title = { Text("Daily water target") },
        text = { OutlinedTextField(targetInput, { value -> targetInput = value.filter { it.isDigit() }.take(5) }, label = { Text("Target in millilitres") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { targetInput.toIntOrNull()?.let(onSetTarget); showTarget = false }, enabled = targetInput.toIntOrNull()?.let { it in 250..10000 } == true) { Text("Save") } },
        dismissButton = { TextButton(onClick = { showTarget = false }) { Text("Cancel") } }
    )
}

@Composable
private fun GoalsScreen(goals: List<GoalItem>, onAddGoal: (String, Int, String) -> Unit, onCompleteGoal: (GoalItem) -> Unit) {
    var showAdd by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillNovaSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenHeading("Goals", "Choose clear, manageable goals and mark them when complete.") }
        item { Button(onClick = { showAdd = true }, modifier = Modifier.fillNovaWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(7.dp)); Text("Add goal") } }
        if (goals.isEmpty()) item { EmptyState("No goals yet", "Add one goal you would like to work toward.", "Create a goal", { showAdd = true }) }
        items(goals, key = { it.id }) { goal ->
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(Modifier.fillNovaWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (goal.isComplete) Icons.Default.CheckCircle else Icons.Default.Bolt, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(goal.title, fontWeight = FontWeight.Bold)
                        Text("Target: ${goal.targetValue} ${goal.unit}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (goal.isComplete) Text("Completed", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                    if (!goal.isComplete) TextButton(onClick = { onCompleteGoal(goal) }) { Text("Complete") }
                }
            }
        }
    }
    if (showAdd) AddGoalDialog(onDismiss = { showAdd = false }, onCreate = { title, target, unit -> onAddGoal(title, target, unit); showAdd = false })
}

@Composable
private fun AddGoalDialog(onDismiss: () -> Unit, onCreate: (String, Int, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("times") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New goal") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Goal title") }, singleLine = true)
                OutlinedTextField(target, { value -> target = value.filter { it.isDigit() }.take(6) }, label = { Text("Target amount") }, singleLine = true)
                OutlinedTextField(unit, { unit = it }, label = { Text("Unit (optional)") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { target.toIntOrNull()?.let { onCreate(title, it, unit) } }, enabled = title.isNotBlank() && target.toIntOrNull()?.let { it in 1..100000 } == true) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun RemindersScreen(
    reminders: List<ReminderItem>,
    onCreateReminder: (String, Int, Int) -> Unit,
    onToggleReminder: (ReminderItem, Boolean) -> Unit,
    onDeleteReminder: (ReminderItem) -> Unit
) {
    val context = LocalContext.current
    var showAdd by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<ReminderItem?>(null) }
    var reminderTitle by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillNovaSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenHeading("Reminders", "Daily reminders are scheduled on this device; Android may delay them to save power.") }
        item { Button(onClick = { reminderTitle = ""; showAdd = true }, modifier = Modifier.fillNovaWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(7.dp)); Text("Add daily reminder") } }
        if (reminders.isEmpty()) item { EmptyState("No reminders", "Create a daily prompt for a routine you want to remember.", "Create reminder", { showAdd = true }) }
        items(reminders, key = { it.id }) { reminder ->
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(Modifier.fillNovaWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Bolt, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(reminder.title, fontWeight = FontWeight.Bold)
                        Text("${reminder.timeLabel} · daily", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = reminder.enabled, onCheckedChange = { onToggleReminder(reminder, it) })
                    TextButton(onClick = { pendingDelete = reminder }) { Text("Delete") }
                }
            }
        }
    }
    if (showAdd) AlertDialog(
        onDismissRequest = { showAdd = false },
        title = { Text("Daily reminder") },
        text = { OutlinedTextField(reminderTitle, { reminderTitle = it }, label = { Text("Reminder message") }, placeholder = { Text("Drink water / Stretch break") }, singleLine = true) },
        confirmButton = {
            TextButton(onClick = {
                val title = reminderTitle.trim()
                if (title.isNotBlank()) {
                    showAdd = false
                    TimePickerDialog(context, { _, hour, minute -> onCreateReminder(title, hour, minute) }, 9, 0, true).show()
                }
            }, enabled = reminderTitle.isNotBlank()) { Text("Choose time") }
        },
        dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
    )
    pendingDelete?.let { reminder ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete reminder?") },
            text = { Text("Remove “${reminder.title}” from your reminders?") },
            confirmButton = { TextButton(onClick = { onDeleteReminder(reminder); pendingDelete = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ProgressScreen(
    tasks: List<TaskItem>,
    waterMl: Int,
    waterTarget: Int,
    workoutsCompleted: Int,
    meals: List<MealLogItem>,
    goals: List<GoalItem>,
    waterTotals: List<Pair<String, Int>>,
    workoutTotals: List<Pair<String, Int>>
) {
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    val completedToday = tasks.count { it.isDone && it.completedAt != null && SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it.completedAt)) == today }
    val totalToday = tasks.count {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it.createdAt)) == today ||
            (it.isDone && it.completedAt != null && SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it.completedAt)) == today)
    }
    val mealsToday = meals.count { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it.loggedAt)) == today }
    val waterTop = waterTotals.maxOfOrNull { it.second }?.coerceAtLeast(1) ?: 1
    val workoutTop = workoutTotals.maxOfOrNull { it.second }?.coerceAtLeast(1) ?: 1
    LazyColumn(Modifier.fillNovaSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScreenHeading("Progress", "Insights calculated only from data saved in VitaFlow.") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillNovaWidth()) {
                MetricCard(Modifier.weight(1f), Icons.Default.CheckCircle, "Tasks today", "$completedToday/$totalToday", "Completed today")
                MetricCard(Modifier.weight(1f), Icons.Default.WaterDrop, "Water today", "$waterMl ml", "Target $waterTarget ml")
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillNovaWidth()) {
                MetricCard(Modifier.weight(1f), Icons.Default.FitnessCenter, "Workouts", workoutsCompleted.toString(), "All-time sessions")
                MetricCard(Modifier.weight(1f), Icons.Default.Chat, "Meals today", mealsToday.toString(), "Logged meals")
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillNovaWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Water · last 7 days", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    waterTotals.forEach { (day, amount) ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text(day, modifier = Modifier.width(42.dp), style = MaterialTheme.typography.bodySmall)
                            LinearProgressIndicator(progress = { (amount.toFloat() / waterTop).coerceIn(0f, 1f) }, modifier = Modifier.weight(1f).height(7.dp).clip(CircleShape))
                            Text("${amount} ml", modifier = Modifier.width(67.dp), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillNovaWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Workouts · last 7 days", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    workoutTotals.forEach { (day, amount) ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            Text(day, modifier = Modifier.width(42.dp), style = MaterialTheme.typography.bodySmall)
                            LinearProgressIndicator(progress = { (amount.toFloat() / workoutTop).coerceIn(0f, 1f) }, modifier = Modifier.weight(1f).height(7.dp).clip(CircleShape))
                            Text("$amount", modifier = Modifier.width(67.dp), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
        item {
            Text("Goals complete: ${goals.count { it.isComplete }} · active goals: ${goals.count { !it.isComplete }}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { Text("These are activity summaries, not medical or fitness diagnoses. Missing historical entries are not estimated.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun NovaScreen(
    messages: List<ChatMessage>,
    isWorking: Boolean,
    onSend: (String) -> Unit,
    onMic: () -> Unit,
    onSuggestedPrompt: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillNovaSize()) {
        Row(
            modifier = Modifier.fillNovaWidth().padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(45.dp).clip(CircleShape).background(MaterialTheme.colorScheme.tertiary), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Bolt, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(25.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Nova", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("VitaFlow AI assistant", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onMic) { Icon(Icons.Default.Mic, contentDescription = "Talk to Nova", tint = MaterialTheme.colorScheme.primary) }
        }
        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
        LazyColumn(
            modifier = Modifier.weight(1f).fillNovaWidth(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 15.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.id }) { message -> ChatBubble(message) }
            if (isWorking) item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.padding(start = 5.dp)) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Text("Nova is thinking…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (messages.size <= 1 && !isWorking) item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Try asking", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    listOf("Create a task: read for 20 minutes", "Log 250 ml of water", "Show my progress").forEach { prompt ->
                        SuggestionChip(prompt = prompt, onClick = { onSuggestedPrompt(prompt) })
                    }
                }
            }
        }
        Row(
            Modifier.fillNovaWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onMic, enabled = !isWorking) { Icon(Icons.Default.Mic, contentDescription = "Voice input") }
            TextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask Nova anything…") },
                shape = RoundedCornerShape(22.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { if (input.isNotBlank() && !isWorking) { onSend(input); input = "" } }),
                maxLines = 4
            )
            IconButton(
                onClick = { if (input.isNotBlank() && !isWorking) { onSend(input); input = "" } },
                enabled = input.isNotBlank() && !isWorking
            ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.primary) }
        }
    }
}

@Composable
private fun ChatBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillNovaWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .fillNovaWidth(0.88f)
                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomEnd = if (message.fromUser) 5.dp else 20.dp, bottomStart = if (message.fromUser) 20.dp else 5.dp))
                .background(if (message.fromUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
                .padding(horizontal = 15.dp, vertical = 12.dp)
        ) {
            Text(message.text, color = if (message.fromUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun SuggestionChip(prompt: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillNovaWidth()) {
        Text(prompt, modifier = Modifier.fillNovaWidth(), color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun SettingsScreen(
    repository: VitaFlowRepository,
    wakeWordEnabled: Boolean,
    darkMode: Boolean,
    language: String,
    onLanguageChange: (String) -> Unit,
    onWakeWordChange: (Boolean) -> Unit,
    onDarkModeChange: (Boolean) -> Unit,
    onGoogleSignIn: ((String) -> Unit) -> Unit,
    onGoogleSignOut: ((String) -> Unit) -> Unit,
    onMessage: (String) -> Unit
) {
    var signedIn by remember { mutableStateOf(repository.isSignedIn()) }
    val name = repository.currentUserName()
    val email = repository.currentUserEmail()
    LazyColumn(
        modifier = Modifier.fillNovaSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenHeading(
                if (language == "bn") "সেটিংস" else "Settings",
                if (language == "bn") "VitaFlow-কে নিজের মতো সাজাও।" else "Make VitaFlow work the way you do."
            )
        }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillNovaWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (language == "bn") "অ্যাপের ভাষা" else "App language", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(if (language == "bn") "বাংলা বা English বেছে নাও" else "Choose Bengali or English", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillNovaWidth()) {
                        if (language == "bn") {
                            Button(onClick = { onLanguageChange("bn") }, modifier = Modifier.weight(1f)) { Text("বাংলা ✓") }
                            OutlinedButton(onClick = { onLanguageChange("en") }, modifier = Modifier.weight(1f)) { Text("English") }
                        } else {
                            OutlinedButton(onClick = { onLanguageChange("bn") }, modifier = Modifier.weight(1f)) { Text("বাংলা") }
                            Button(onClick = { onLanguageChange("en") }, modifier = Modifier.weight(1f)) { Text("English ✓") }
                        }
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(23.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(Modifier.fillNovaWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.tertiary), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Person, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                    }
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (signedIn) name.ifBlank { "Signed in" } else "Personal profile", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(if (signedIn) email else "Sign in to sync across sessions", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Row(Modifier.fillNovaWidth().padding(start = 17.dp, end = 17.dp, bottom = 17.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (signedIn) {
                        OutlinedButton(
                            onClick = { onGoogleSignOut { signedIn = false } },
                            modifier = Modifier.fillNovaWidth()
                        ) { Text("Sign out") }
                    } else {
                        Button(
                            onClick = { onGoogleSignIn { signedIn = repository.isSignedIn() } },
                            modifier = Modifier.fillNovaWidth()
                        ) { Text("Continue with Google") }
                    }
                }
            }
        }
        item {
            SettingsToggleCard(
                icon = Icons.Default.Mic,
                title = "Hey Nova wake phrase",
                subtitle = "Listens only while VitaFlow is in the foreground. Device speech service availability may vary.",
                checked = wakeWordEnabled,
                onCheckedChange = onWakeWordChange
            )
        }
        item {
            SettingsToggleCard(
                icon = Icons.Default.DarkMode,
                title = if (language == "bn") "ডার্ক থিম" else "Dark appearance",
                subtitle = if (language == "bn") "VitaFlow-এর ডার্ক থিম ব্যবহার করো।" else "Use VitaFlow's dark colour theme.",
                checked = darkMode,
                onCheckedChange = onDarkModeChange
            )
        }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.fillNovaWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(9.dp))
                        Text(if (language == "bn") "গোপনীয়তা ও সিঙ্ক" else "Privacy & sync", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        if (repository.hasFirebaseConfiguration()) "Local tracking is saved on this device. When signed in, supported records sync under your Firebase user ID." else "Firebase is not configured yet. Local tasks and hydration are saved on this device; Nova AI and cloud sign-in require a Firebase project.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        item {
            Text("VITAFLOW · 0.1.0 · Personal-use starter", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingsToggleCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillNovaWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(MaterialTheme.colorScheme.tertiary), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(3.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}

@Composable
private fun TaskRow(task: TaskItem, onComplete: () -> Unit) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillNovaWidth().padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = task.isDone, onCheckedChange = { checked -> if (checked) onComplete() }, enabled = !task.isDone)
            Column(Modifier.weight(1f).padding(vertical = 4.dp)) {
                Text(task.title, fontWeight = FontWeight.SemiBold, color = if (task.isDone) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
                Text(if (task.isDone) "Completed" else "Open task", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (task.isDone) Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun ScreenHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(bottom = 5.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String, action: String, onAction: () -> Unit) {
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillNovaWidth().padding(23.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(35.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onAction) { Text(action) }
        }
    }
}

@Composable
private fun AddTaskDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var title by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New task") },
        text = {
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task title") }, placeholder = { Text("e.g. Read for 20 minutes") }, singleLine = true)
        },
        confirmButton = { TextButton(onClick = { if (title.isNotBlank()) onCreate(title) }, enabled = title.isNotBlank()) { Text("Add task") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun EditGoalDialog(currentGoal: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var goal by remember(currentGoal) { mutableStateOf(currentGoal) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Today's focus") },
        text = { OutlinedTextField(value = goal, onValueChange = { goal = it }, label = { Text("Daily goal") }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (goal.isNotBlank()) onSave(goal) }, enabled = goal.isNotBlank()) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
