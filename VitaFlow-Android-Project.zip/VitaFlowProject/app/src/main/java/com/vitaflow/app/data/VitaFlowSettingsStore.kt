package com.vitaflow.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.vitaflowSettingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "vitaflow_settings")

data class VitaFlowSettings(
    val darkMode: Boolean = false,
    val wakeWordEnabled: Boolean = false,
    val dailyGoal: String = "Move with purpose",
    val waterTargetMl: Int = 2000,
    val language: String = "bn"
)

/** Preferences-only storage. Structured activity records remain in the repository's local JSON store. */
class VitaFlowSettingsStore(private val context: Context) {
    val settings: Flow<VitaFlowSettings> = context.vitaflowSettingsDataStore.data
        .catch { emit(emptyPreferences()) }
        .map { preferences ->
            VitaFlowSettings(
                darkMode = preferences[KEY_DARK_MODE] ?: false,
                wakeWordEnabled = preferences[KEY_WAKE_WORD] ?: false,
                dailyGoal = preferences[KEY_DAILY_GOAL] ?: "Move with purpose",
                waterTargetMl = (preferences[KEY_WATER_TARGET] ?: 2000).coerceIn(250, 10000),
                language = (preferences[KEY_LANGUAGE] ?: "bn").takeIf { it == "bn" || it == "en" } ?: "bn"
            )
        }

    suspend fun setDarkMode(value: Boolean) {
        context.vitaflowSettingsDataStore.edit { it[KEY_DARK_MODE] = value }
    }

    suspend fun setWakeWordEnabled(value: Boolean) {
        context.vitaflowSettingsDataStore.edit { it[KEY_WAKE_WORD] = value }
    }

    suspend fun setDailyGoal(value: String) {
        context.vitaflowSettingsDataStore.edit { it[KEY_DAILY_GOAL] = value.take(100) }
    }

    suspend fun setWaterTarget(value: Int) {
        context.vitaflowSettingsDataStore.edit { it[KEY_WATER_TARGET] = value.coerceIn(250, 10000) }
    }

    suspend fun setLanguage(value: String) {
        context.vitaflowSettingsDataStore.edit { it[KEY_LANGUAGE] = if (value == "en") "en" else "bn" }
    }

    companion object {
        private val KEY_DARK_MODE = booleanPreferencesKey("dark_mode")
        private val KEY_WAKE_WORD = booleanPreferencesKey("wake_word_enabled")
        private val KEY_DAILY_GOAL = stringPreferencesKey("daily_goal")
        private val KEY_WATER_TARGET = intPreferencesKey("water_target_ml")
        private val KEY_LANGUAGE = stringPreferencesKey("ui_language")
    }
}
