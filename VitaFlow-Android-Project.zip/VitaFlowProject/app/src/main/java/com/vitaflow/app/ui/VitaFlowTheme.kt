package com.vitaflow.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val VitaFlowGreen = Color(0xFF1F7553)
private val VitaFlowLime = Color(0xFFB8F36B)
private val LightColors = lightColorScheme(
    primary = VitaFlowGreen,
    onPrimary = Color.White,
    secondary = Color(0xFF58784D),
    tertiary = Color(0xFFDFEDC6),
    background = Color(0xFFF4F7F3),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE8EEE7),
    onSurface = Color(0xFF18231C),
    onSurfaceVariant = Color(0xFF5A665E),
    outline = Color(0xFFD4DED4)
)
private val DarkColors = darkColorScheme(
    primary = VitaFlowLime,
    onPrimary = Color(0xFF183424),
    secondary = Color(0xFFC6DDB6),
    tertiary = Color(0xFF2C4636),
    background = Color(0xFF101712),
    surface = Color(0xFF18211B),
    surfaceVariant = Color(0xFF26332A),
    onSurface = Color(0xFFECF5ED),
    onSurfaceVariant = Color(0xFFB4C2B7),
    outline = Color(0xFF3E4B41)
)

@Composable
fun VitaFlowTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
