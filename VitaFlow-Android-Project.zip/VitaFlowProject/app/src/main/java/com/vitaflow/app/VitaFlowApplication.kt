package com.vitaflow.app

import android.app.Application
import com.google.firebase.FirebaseApp

class VitaFlowApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Firebase is intentionally optional during the first local-only launch.
        // Adding app/google-services.json activates Firebase features.
        runCatching { FirebaseApp.initializeApp(this) }
        if (runCatching { FirebaseApp.getApps(this).isNotEmpty() }.getOrDefault(false)) {
            runCatching { AppCheckBootstrap.install() }
        }
    }
}
