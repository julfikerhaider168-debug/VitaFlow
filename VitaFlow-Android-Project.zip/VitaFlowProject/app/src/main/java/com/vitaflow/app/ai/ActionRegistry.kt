package com.vitaflow.app.ai

import com.vitaflow.app.data.VitaFlowRepository
import com.vitaflow.app.model.ActionResult
import org.json.JSONObject
import java.util.Locale

/**
 * Security boundary between untrusted model output and app state.
 * Only named operations below can be executed; all arguments are revalidated by the repository.
 */
class ActionRegistry(private val repository: VitaFlowRepository) {
    fun execute(name: String, args: JSONObject): ActionResult = when (name.trim().uppercase(Locale.ROOT)) {
        "CREATE_TASK" -> repository.addTask(args.optString("title"))
        "COMPLETE_TASK" -> repository.completeTask(args.optString("title", args.optString("taskId")))
        "LOG_WATER_INTAKE" -> repository.addWater(args.optInt("amountMl", -1))
        "SET_HYDRATION_TARGET" -> repository.setWaterTarget(args.optInt("amountMl", -1))
        "SET_DAILY_GOAL" -> repository.setDailyGoal(args.optString("goal"))
        "ADD_GOAL" -> repository.addGoal(
            rawTitle = args.optString("title"),
            targetValue = args.optInt("targetValue", 1),
            unit = args.optString("unit", "times")
        )
        "COMPLETE_GOAL" -> repository.completeGoal(args.optString("title"))
        "COMPLETE_WORKOUT" -> repository.completeWorkout(
            workoutName = args.optString("workoutName"),
            durationMinutes = args.optInt("durationMinutes", 15)
        )
        "LOG_MEAL" -> repository.addMeal(
            rawName = args.optString("name"),
            mealType = args.optString("mealType", "Snack"),
            calories = if (args.has("calories") && !args.isNull("calories")) args.optInt("calories", -1) else null,
            note = args.optString("note", "")
        )
        "CREATE_MEAL_PLAN" -> repository.addMealPlan(
            titleRaw = args.optString("title"),
            breakfastRaw = args.optString("breakfast"),
            lunchRaw = args.optString("lunch"),
            dinnerRaw = args.optString("dinner"),
            snackRaw = args.optString("snack", ""),
            notesRaw = args.optString("notes", "")
        )
        "CREATE_WORKOUT_PLAN" -> repository.addWorkoutPlan(
            titleRaw = args.optString("title"),
            focusRaw = args.optString("focus", "General fitness"),
            durationMinutes = args.optInt("durationMinutes", 15),
            exercisesRaw = args.optString("exercises")
        )
        "CREATE_REMINDER" -> createReminder(args)
        "SET_REMINDER_ENABLED" -> setReminderEnabled(args)
        "GET_PROGRESS" -> {
            val progress = repository.progressSummary()
            ActionResult(
                true,
                "VitaFlow-তে সেভ করা তথ্য অনুযায়ী তোমার অগ্রগতি:\n" +
                    "• আজকের task সম্পন্ন: ${progress.optInt("tasksCompletedToday")} / ${progress.optInt("tasksTotal")}\n" +
                    "• আজকের পানি: ${progress.optInt("waterMlToday")} / ${progress.optInt("waterTargetMl")} ml\n" +
                    "• আজ workout: ${progress.optInt("workoutsToday")}টি; মোট ${progress.optInt("workoutSessionsAllTime")}টি session\n" +
                    "• আজ meal log: ${progress.optInt("mealsLoggedToday")}টি\n" +
                    "• অসম্পন্ন goal: ${progress.optInt("activeGoals")}টি"
            )
        }
        "GET_TASKS" -> {
            val list = repository.tasks.value.take(12)
            ActionResult(true, if (list.isEmpty()) "এখনো কোনো task সেভ করা নেই।" else list.joinToString("\n") {
                "${if (it.isDone) "✓" else "•"} ${it.title}"
            })
        }
        "GET_HYDRATION" -> ActionResult(
            true,
            "আজ পানি: ${repository.waterMl.value} / ${repository.waterTargetMl.value} ml। বাকি ${maxOf(0, repository.waterTargetMl.value - repository.waterMl.value)} ml।"
        )
        "GET_GOALS" -> {
            val goals = repository.goals.value.take(15)
            ActionResult(true, if (goals.isEmpty()) "এখনো কোনো goal সেভ করা নেই।" else goals.joinToString("\n") {
                "${if (it.isComplete) "✓" else "•"} ${it.title} (target ${it.targetValue} ${it.unit})"
            })
        }
        "GET_REMINDERS" -> {
            val reminders = repository.reminders.value.take(15)
            ActionResult(true, if (reminders.isEmpty()) "এখনো কোনো reminder সেভ করা নেই।" else reminders.joinToString("\n") {
                "${if (it.enabled) "●" else "○"} ${it.title} — ${it.timeLabel}${if (it.repeatDaily) " (প্রতিদিন)" else ""}"
            })
        }
        "GET_MEALS" -> {
            val meals = repository.meals.value.take(10)
            ActionResult(true, if (meals.isEmpty()) "এখনো কোনো খাবার লগ করা নেই।" else meals.joinToString("\n") {
                "• ${it.mealType}: ${it.name}${it.calories?.let { kcal -> " — আনুমানিক $kcal kcal" } ?: ""}"
            })
        }
        "GET_MEAL_PLANS" -> {
            val plans = repository.mealPlans.value.take(10)
            ActionResult(true, if (plans.isEmpty()) "এখনো কোনো meal plan সেভ করা নেই।" else plans.joinToString("\n\n") {
                "${it.title}\nBreakfast: ${it.breakfast}\nLunch: ${it.lunch}\nDinner: ${it.dinner}" + if (it.snack.isBlank()) "" else "\nSnack: ${it.snack}"
            })
        }
        "GET_WORKOUT_PLANS" -> {
            val plans = repository.workoutPlans.value.take(10)
            ActionResult(true, if (plans.isEmpty()) "এখনো কোনো workout plan সেভ করা নেই।" else plans.joinToString("\n\n") {
                "${it.title} — ${it.durationMinutes} min (${it.focus})\n${it.exercises}"
            })
        }
        "GET_WORKOUT_HISTORY" -> {
            val sessions = repository.workoutHistory.value.takeLast(10).reversed()
            ActionResult(true, if (sessions.isEmpty()) "এখনো কোনো workout session লগ করা নেই।" else sessions.joinToString("\n") {
                "• ${it.name} — ${it.durationMinutes} min"
            })
        }
        "GET_WORKOUT_LIBRARY" -> ActionResult(
            true,
            "VitaFlow-র starter workout library:\n• Full-body basics — 15–20 min, beginner-friendly\n• Mobility reset — 8–10 min, gentle\n• Cardio walk — 10–25 min, adjustable\n\nনিজের আরামদায়ক level বেছে নাও; অস্বস্তি বা ব্যথা হলে থেমে যাও।"
        )
        else -> ActionResult(false, "এই কাজটি Nova-এর অনুমোদিত action তালিকায় নেই, তাই আমি এটি চালাইনি।")
    }

    private fun createReminder(args: JSONObject): ActionResult {
        val title = args.optString("title").trim()
        val time = args.optString("time").trim()
        val match = Regex("^(\\d{1,2}):(\\d{2})$").matchEntire(time)
            ?: return ActionResult(false, "Reminder-এর সময়টি ২৪ ঘণ্টার format-এ বলো, যেমন 09:30 বা 18:15।")
        val hour = match.groupValues[1].toIntOrNull() ?: -1
        val minute = match.groupValues[2].toIntOrNull() ?: -1
        return repository.addReminder(title, hour, minute)
    }

    private fun setReminderEnabled(args: JSONObject): ActionResult {
        val query = args.optString("title").trim()
        if (query.isBlank()) return ActionResult(false, "কোন reminder চালু বা বন্ধ করতে হবে, তার নাম বলো।")
        val matches = repository.reminders.value.filter { it.title.equals(query, true) || it.id == query }
        if (matches.isEmpty()) return ActionResult(false, "এই নামে কোনো reminder পাওয়া যায়নি।")
        if (matches.size > 1) return ActionResult(false, "একই নামের একাধিক reminder আছে। নির্দিষ্ট সময়টিও বলো বা সেটিংস থেকে বেছে নাও।")
        return repository.toggleReminder(matches.first().id, args.optBoolean("enabled", true))
    }
}
