package com.vitaflow.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import androidx.credentials.CredentialManager
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.vitaflow.app.data.VitaFlowRepository
import com.vitaflow.app.ui.VitaFlowApp
import com.vitaflow.app.voice.VoiceController
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : ComponentActivity() {
    private lateinit var voiceController: VoiceController
    private val credentialManager by lazy { CredentialManager.create(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        voiceController = VoiceController(this)
        setContent {
            val repository = androidx.compose.runtime.remember { VitaFlowRepository(applicationContext) }
            VitaFlowApp(
                repository = repository,
                voiceController = voiceController,
                onGoogleSignIn = { onResult -> startGoogleSignIn(repository, onResult) },
                onGoogleSignOut = { onResult -> signOutGoogle(repository, onResult) }
            )
        }
    }

    private fun startGoogleSignIn(repository: VitaFlowRepository, onResult: (String) -> Unit) {
        if (!repository.hasFirebaseConfiguration()) {
            onResult("আগে app/google-services.json যোগ করে Firebase Authentication-এ Google provider চালু করো।")
            return
        }
        val clientIdRes = resources.getIdentifier("default_web_client_id", "string", packageName)
        val webClientId = if (clientIdRes == 0) "" else runCatching { getString(clientIdRes) }.getOrDefault("")
        if (webClientId.isBlank()) {
            onResult("Google Sign-In-এর Web client ID পাওয়া যায়নি। সঠিক google-services.json যোগ করো।")
            return
        }

        lifecycleScope.launch {
            try {
                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(webClientId)
                    .setAutoSelectEnabled(false)
                    .build()
                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()
                val response = credentialManager.getCredential(this@MainActivity, request)
                val credential = response.credential
                if (credential !is CustomCredential || credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    onResult("Google account credential-এর ধরনটি সমর্থিত নয়। আবার চেষ্টা করো।")
                    return@launch
                }
                val googleToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val firebaseCredential = GoogleAuthProvider.getCredential(googleToken, null)
                FirebaseAuth.getInstance().signInWithCredential(firebaseCredential).await()
                onResult("Google account দিয়ে সাইন ইন হয়েছে।")
            } catch (error: Exception) {
                val message = error.message.orEmpty()
                val userMessage = when {
                    message.contains("cancel", ignoreCase = true) -> "Google Sign-In বাতিল হয়েছে।"
                    message.contains("network", ignoreCase = true) -> "নেটওয়ার্ক সমস্যা হয়েছে। আবার চেষ্টা করো।"
                    else -> "Google Sign-In ব্যর্থ হয়েছে। Firebase Authentication-এ Google provider, Web client ID এবং SHA certificate যাচাই করো।"
                }
                onResult(userMessage)
            }
        }
    }

    private fun signOutGoogle(repository: VitaFlowRepository, onResult: (String) -> Unit) {
        if (!repository.hasFirebaseConfiguration()) {
            onResult("Firebase configuration এখনও যোগ করা হয়নি।")
            return
        }
        FirebaseAuth.getInstance().signOut()
        lifecycleScope.launch {
            runCatching { credentialManager.clearCredentialState(ClearCredentialStateRequest()) }
            onResult("এই ডিভাইস থেকে সাইন আউট হয়েছে।")
        }
    }

    override fun onDestroy() {
        if (::voiceController.isInitialized) voiceController.destroy()
        super.onDestroy()
    }
}
