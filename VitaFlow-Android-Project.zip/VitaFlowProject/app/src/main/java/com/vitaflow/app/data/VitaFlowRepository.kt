package com.vitaflow.app.data

import android.content.Context
import com.vitaflow.app.model.ActionResult
import com.vitaflow.app.model.ChatMessage
import com.vitaflow.app.model.GoalItem
import com.vitaflow.app.model.MealLogItem
import com.vitaflow.app.model.MealPlanItem
import com.vitaflow.app.model.ReminderItem
import com.vitaflow.app.model.TaskItem
import com.vitaflow.app.model.WaterLogItem
import com.vitaflow.app.model.WorkoutSession
import com.vitaflow.app.model.WorkoutPlanItem
import com.vitaflow.app.reminders.ReminderScheduler
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Local-first repository. Cloud data is isolated beneath the signed-in Firebase UID. */
class VitaFlowRepository(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("vitaflow_local_v2", Context.MODE_PRIVATE)
    private val settingsStore = VitaFlowSettingsStore(appContext)
    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _tasks = MutableStateFlow(loadArray(KEY_TASKS, TaskItem::fromJson))
    val tasks: StateFlow<List<TaskItem>> = _tasks

    private val _waterLogs = MutableStateFlow(loadArray(KEY_WATER_LOGS, WaterLogItem::fromJson).takeLast(NOVA_LOG_ITEMS))
    val waterLogs: StateFlow<List<WaterLogItem>> = _waterLogs

    private val _waterMl = MutableStateFlow(loadTodayWater())
    val waterMl: StateFlow<Int> = _waterMl

    private val _waterTargetMl = MutableStateFlow(prefs.getInt(KEY_WATER_TARGET, DEFAULT_WATER_TARGET).coerceIn(250, 10000))
    val waterTargetMl: StateFlow<Int> = _waterTargetMl

    private val _workoutHistory = MutableStateFlow(loadArray(KEY_WORKOUT_HISTORY, WorkoutSession::fromJson).takeLast(NOVA_LOG_ITEMS))
    val workoutHistory: StateFlow<List<WorkoutSession>> = _workoutHistory

    private val _workoutsCompleted = MutableStateFlow(prefs.getInt(KEY_WORKOUT_COUNT, _workoutHistory.value.size).coerceAtLeast(0))
    val workoutsCompleted: StateFlow<Int> = _workoutsCompleted

    private val _meals = MutableStateFlow(loadArray(KEY_MEALS, MealLogItem::fromJson).takeLast(NOVA_LOG_ITEMS))
    val meals: StateFlow<List<MealLogItem>> = _meals

    private val _mealPlans = MutableStateFlow(loadArray(KEY_MEAL_PLANS, MealPlanItem::fromJson).takeLast(100))
    val mealPlans: StateFlow<List<MealPlanItem>> = _mealPlans

    private val _workoutPlans = MutableStateFlow(loadArray(KEY_WORKOUT_PLANS, WorkoutPlanItem::fromJson).takeLast(100))
    val workoutPlans: StateFlow<List<WorkoutPlanItem>> = _workoutPlans

    private val _reminders = MutableStateFlow(loadArray(KEY_REMINDERS, ReminderItem::fromJson))
    val reminders: StateFlow<List<ReminderItem>> = _reminders

    private val _goals = MutableStateFlow(loadArray(KEY_GOALS, GoalItem::fromJson))
    val goals: StateFlow<List<GoalItem>> = _goals

    private val _dailyGoal = MutableStateFlow(prefs.getString(KEY_DAILY_GOAL, "Move with purpose") ?: "Move with purpose")
    val dailyGoal: StateFlow<String> = _dailyGoal

    private val _wakeWordEnabled = MutableStateFlow(prefs.getBoolean(KEY_WAKE_ENABLED, false))
    val wakeWordEnabled: StateFlow<Boolean> = _wakeWordEnabled

    private val _darkMode = MutableStateFlow(prefs.getBoolean(KEY_DARK_MODE, false))
    val darkMode: StateFlow<Boolean> = _darkMode

    private val _language = MutableStateFlow("bn")
    val language: StateFlow<String> = _language

    init {
        repositoryScope.launch {
            settingsStore.settings.collect { settings ->
                _waterTargetMl.value = settings.waterTargetMl
                _dailyGoal.value = settings.dailyGoal
                _wakeWordEnabled.value = settings.wakeWordEnabled
                _darkMode.value = settings.darkMode
                _language.value = settings.language
            }
        }
    }

    fun addTask(rawTitle: String): ActionResult {
        val title = rawTitle.trim().take(120)
        if (title.isBlank()) return ActionResult(false, "Task-এর নাম লিখতে হবে।")
        if (_tasks.value.any { it.title.equals(title, ignoreCase = true) && !it.isDone }) {
            return ActionResult(false, "এই task-টি আগে থেকেই আছে।")
        }
        val task = TaskItem(title = title)
        _tasks.value = (listOf(task) + _tasks.value).take(NOVA_LOG_ITEMS)
        saveArray(KEY_TASKS, _tasks.value.map { it.toJson() })
        syncTask(task)
        return ActionResult(true, "Task যোগ হয়েছে: $title")
    }

    fun completeTask(query: String): ActionResult {
        val cleaned = query.trim()
        if (cleaned.isBlank()) return ActionResult(false, "কোন task সম্পন্ন করতে হবে, সেটি বলো।")
        val candidates = _tasks.value.filter {
            !it.isDone && (it.id.equals(cleaned, true) || it.title.equals(cleaned, true) || it.title.contains(cleaned, true))
        }
        if (candidates.isEmpty()) return ActionResult(false, "অসম্পন্ন এমন কোনো task পাইনি: $cleaned")
        if (candidates.size > 1) return ActionResult(false, "একাধিক task মিলেছে। অনুগ্রহ করে task-এর পুরো নাম বলো।")
        val completed = candidates.first().copy(isDone = true, completedAt = System.currentTimeMillis())
        _tasks.value = _tasks.value.map { if (it.id == completed.id) completed else it }
        saveArray(KEY_TASKS, _tasks.value.map { it.toJson() })
        syncTask(completed)
        return ActionResult(true, "Task সম্পন্ন হয়েছে: ${completed.title}")
    }

    fun addWater(amountMl: Int): ActionResult {
        if (amountMl !in 50..2000) return ActionResult(false, "একবারে পানির পরিমাণ ৫০–২০০০ ml-এর মধ্যে দাও।")
        ensureWaterDate()
        val log = WaterLogItem(amountMl = amountMl, date = dateKey())
        _waterMl.value = (_waterMl.value + amountMl).coerceAtMost(100000)
        _waterLogs.value = (_waterLogs.value + log).takeLast(NOVA_LOG_ITEMS)
        prefs.edit().putInt(KEY_WATER_ML, _waterMl.value).putString(KEY_WATER_DATE, dateKey()).apply()
        saveArray(KEY_WATER_LOGS, _waterLogs.value.map { it.toJson() })
        syncWater(log)
        return ActionResult(true, "$amountMl ml পানি যোগ হয়েছে। আজ মোট ${_waterMl.value} ml।")
    }

    fun setWaterTarget(amountMl: Int): ActionResult {
        if (amountMl !in 250..10000) return ActionResult(false, "পানির লক্ষ্য ২৫০–১০,০০০ ml-এর মধ্যে হতে হবে।")
        _waterTargetMl.value = amountMl
        prefs.edit().putInt(KEY_WATER_TARGET, amountMl).apply()
        repositoryScope.launch { runCatching { settingsStore.setWaterTarget(amountMl) } }
        syncProfile()
        return ActionResult(true, "দৈনিক পানির লক্ষ্য ${amountMl} ml করা হয়েছে।")
    }

    fun setDailyGoal(rawGoal: String): ActionResult {
        val goal = rawGoal.trim().take(100)
        if (goal.isBlank()) return ActionResult(false, "লক্ষ্যের নাম খালি রাখা যাবে না।")
        _dailyGoal.value = goal
        prefs.edit().putString(KEY_DAILY_GOAL, goal).apply()
        repositoryScope.launch { runCatching { settingsStore.setDailyGoal(goal) } }
        syncProfile()
        return ActionResult(true, "আজকের লক্ষ্য আপডেট হয়েছে: $goal")
    }

    fun addGoal(rawTitle: String, targetValue: Int = 1, unit: String = "times"): ActionResult {
        val title = rawTitle.trim().take(100)
        val safeUnit = unit.trim().take(20).ifBlank { "times" }
        if (title.isBlank()) return ActionResult(false, "Goal-এর নাম লিখতে হবে।")
        if (targetValue !in 1..100000) return ActionResult(false, "Goal-এর target ১ থেকে ১০০,০০০-এর মধ্যে হতে হবে।")
        if (_goals.value.any { it.title.equals(title, true) && !it.isComplete }) return ActionResult(false, "এই goal-টি আগেই যোগ করা আছে।")
        val goal = GoalItem(title = title, targetValue = targetValue, unit = safeUnit)
        _goals.value = (listOf(goal) + _goals.value).take(NOVA_LOG_ITEMS)
        saveArray(KEY_GOALS, _goals.value.map { it.toJson() })
        syncDocument("goals", goal.id, goal.toJson().toMap())
        return ActionResult(true, "Goal যোগ হয়েছে: $title")
    }

    fun completeGoal(query: String): ActionResult {
        val cleaned = query.trim()
        if (cleaned.isBlank()) return ActionResult(false, "কোন goal সম্পন্ন করতে হবে, সেটি বলো।")
        val matches = _goals.value.filter { !it.isComplete && (it.id == cleaned || it.title.equals(cleaned, true) || it.title.contains(cleaned, true)) }
        if (matches.isEmpty()) return ActionResult(false, "এমন কোনো অসম্পন্ন goal পাওয়া যায়নি।")
        if (matches.size > 1) return ActionResult(false, "একাধিক goal মিলেছে। পুরো নামটি বলো।")
        val updated = matches.first().copy(isComplete = true, completedAt = System.currentTimeMillis())
        _goals.value = _goals.value.map { if (it.id == updated.id) updated else it }
        saveArray(KEY_GOALS, _goals.value.map { it.toJson() })
        syncDocument("goals", updated.id, updated.toJson().toMap())
        return ActionResult(true, "Goal সম্পন্ন হয়েছে: ${updated.title}")
    }

    fun addMeal(rawName: String, mealType: String = "Snack", calories: Int? = null, note: String = ""): ActionResult {
        val name = rawName.trim().take(120)
        if (name.isBlank()) return ActionResult(false, "খাবারের নাম লিখতে হবে।")
        if (calories != null && calories !in 0..10000) return ActionResult(false, "ক্যালোরি ০–১০,০০০-এর মধ্যে দাও, অথবা খালি রাখো।")
        val validTypes = setOf("Breakfast", "Lunch", "Dinner", "Snack", "নাস্তা", "দুপুরের খাবার", "রাতের খাবার")
        val type = mealType.trim().take(40).let { if (it in validTypes) it else "Snack" }
        val item = MealLogItem(name = name, mealType = type, calories = calories, note = note.trim().take(200))
        _meals.value = (listOf(item) + _meals.value).takeLast(NOVA_LOG_ITEMS)
        saveArray(KEY_MEALS, _meals.value.map { it.toJson() })
        syncDocument("mealLogs", item.id, item.toJson().toMap())
        return ActionResult(true, "খাবার লগ হয়েছে: $name${calories?.let { " (আনুমানিক $it kcal)" } ?: ""}। ক্যালোরি দিলে সেটি আনুমানিক হিসেবে ধরো।")
    }

    fun deleteMeal(id: String): ActionResult {
        val item = _meals.value.firstOrNull { it.id == id } ?: return ActionResult(false, "খাবারের লগটি পাওয়া যায়নি।")
        _meals.value = _meals.value.filterNot { it.id == id }
        saveArray(KEY_MEALS, _meals.value.map { it.toJson() })
        deleteCloudDocument("mealLogs", id)
        return ActionResult(true, "খাবারের লগ মুছে ফেলা হয়েছে: ${item.name}")
    }

    fun addMealPlan(titleRaw: String, breakfastRaw: String, lunchRaw: String, dinnerRaw: String, snackRaw: String = "", notesRaw: String = ""): ActionResult {
        val title = titleRaw.trim().take(100)
        val breakfast = breakfastRaw.trim().take(250)
        val lunch = lunchRaw.trim().take(250)
        val dinner = dinnerRaw.trim().take(250)
        if (title.isBlank()) return ActionResult(false, "Meal plan-এর নাম লিখতে হবে।")
        if (breakfast.isBlank() || lunch.isBlank() || dinner.isBlank()) return ActionResult(false, "Meal plan-এ breakfast, lunch ও dinner—তিনটিই দিতে হবে।")
        if (_mealPlans.value.any { it.title.equals(title, true) }) return ActionResult(false, "এই নামে একটি meal plan আগেই আছে।")
        val plan = MealPlanItem(title = title, breakfast = breakfast, lunch = lunch, dinner = dinner, snack = snackRaw.trim().take(250), notes = notesRaw.trim().take(500))
        _mealPlans.value = (listOf(plan) + _mealPlans.value).take(100)
        saveArray(KEY_MEAL_PLANS, _mealPlans.value.map { it.toJson() })
        syncDocument("mealPlans", plan.id, plan.toJson().toMap())
        return ActionResult(true, "Meal plan সেভ হয়েছে: $title। এটি সাধারণ meal ideas—ব্যক্তিগত চিকিৎসা বা diet prescription নয়।")
    }

    fun deleteMealPlan(id: String): ActionResult {
        val plan = _mealPlans.value.firstOrNull { it.id == id } ?: return ActionResult(false, "Meal plan পাওয়া যায়নি।")
        _mealPlans.value = _mealPlans.value.filterNot { it.id == id }
        saveArray(KEY_MEAL_PLANS, _mealPlans.value.map { it.toJson() })
        deleteCloudDocument("mealPlans", id)
        return ActionResult(true, "Meal plan মুছে ফেলা হয়েছে: ${plan.title}")
    }

    fun addWorkoutPlan(titleRaw: String, focusRaw: String, durationMinutes: Int, exercisesRaw: String): ActionResult {
        val title = titleRaw.trim().take(100)
        val focus = focusRaw.trim().take(80).ifBlank { "General fitness" }
        val exercises = exercisesRaw.trim().take(1000)
        if (title.isBlank()) return ActionResult(false, "Workout plan-এর নাম লিখতে হবে।")
        if (durationMinutes !in 1..300) return ActionResult(false, "Workout plan-এর সময় ১–৩০০ মিনিটের মধ্যে হতে হবে।")
        if (exercises.isBlank()) return ActionResult(false, "Workout plan-এ অন্তত একটি exercise বা activity লিখতে হবে।")
        if (_workoutPlans.value.any { it.title.equals(title, true) }) return ActionResult(false, "এই নামে একটি workout plan আগেই আছে।")
        val plan = WorkoutPlanItem(title = title, focus = focus, durationMinutes = durationMinutes, exercises = exercises)
        _workoutPlans.value = (listOf(plan) + _workoutPlans.value).take(100)
        saveArray(KEY_WORKOUT_PLANS, _workoutPlans.value.map { it.toJson() })
        syncDocument("workoutPlans", plan.id, plan.toJson().toMap())
        return ActionResult(true, "Workout plan সেভ হয়েছে: $title (${durationMinutes} min)। নিজের সক্ষমতা অনুযায়ী modify করো।")
    }

    fun deleteWorkoutPlan(id: String): ActionResult {
        val plan = _workoutPlans.value.firstOrNull { it.id == id } ?: return ActionResult(false, "Workout plan পাওয়া যায়নি।")
        _workoutPlans.value = _workoutPlans.value.filterNot { it.id == id }
        saveArray(KEY_WORKOUT_PLANS, _workoutPlans.value.map { it.toJson() })
        deleteCloudDocument("workoutPlans", id)
        return ActionResult(true, "Workout plan মুছে ফেলা হয়েছে: ${plan.title}")
    }

    fun addReminder(rawTitle: String, hour: Int, minute: Int): ActionResult {
        val title = rawTitle.trim().take(80)
        if (title.isBlank()) return ActionResult(false, "Reminder-এর নাম লিখতে হবে।")
        if (hour !in 0..23 || minute !in 0..59) return ActionResult(false, "সময়টি সঠিক নয়।")
        val duplicate = _reminders.value.any { it.enabled && it.title.equals(title, true) && it.hour == hour && it.minute == minute }
        if (duplicate) return ActionResult(false, "একই reminder এবং সময় আগে থেকেই চালু আছে।")
        val item = ReminderItem(title = title, hour = hour, minute = minute)
        _reminders.value = (listOf(item) + _reminders.value).take(100)
        saveArray(KEY_REMINDERS, _reminders.value.map { it.toJson() })
        val scheduled = ReminderScheduler.schedule(appContext, item)
        syncDocument("reminders", item.id, item.toJson().toMap())
        return ActionResult(
            true,
            if (scheduled) "প্রতিদিন ${item.timeLabel}-এ reminder সেভ ও schedule হয়েছে: $title"
            else "Reminder-এর তথ্য সেভ হয়েছে, কিন্তু Android alarm schedule করতে পারেনি। App ও notification settings যাচাই করো।"
        )
    }

    fun toggleReminder(id: String, enabled: Boolean): ActionResult {
        val found = _reminders.value.firstOrNull { it.id == id } ?: return ActionResult(false, "Reminder পাওয়া যায়নি।")
        val updated = found.copy(enabled = enabled)
        _reminders.value = _reminders.value.map { if (it.id == id) updated else it }
        saveArray(KEY_REMINDERS, _reminders.value.map { it.toJson() })
        val scheduled = if (enabled) ReminderScheduler.schedule(appContext, updated) else {
            ReminderScheduler.cancel(appContext, updated.id)
            true
        }
        syncDocument("reminders", updated.id, updated.toJson().toMap())
        val message = when {
            !enabled -> "Reminder বন্ধ হয়েছে: ${updated.title}"
            scheduled -> "Reminder চালু হয়েছে: ${updated.title}"
            else -> "Reminder চালু হিসেবে সেভ হয়েছে, কিন্তু Android alarm schedule করতে পারেনি। App ও notification settings যাচাই করো।"
        }
        return ActionResult(true, message)
    }

    fun deleteReminder(id: String): ActionResult {
        val found = _reminders.value.firstOrNull { it.id == id } ?: return ActionResult(false, "Reminder পাওয়া যায়নি।")
        ReminderScheduler.cancel(appContext, id)
        _reminders.value = _reminders.value.filterNot { it.id == id }
        saveArray(KEY_REMINDERS, _reminders.value.map { it.toJson() })
        deleteCloudDocument("reminders", id)
        return ActionResult(true, "Reminder মুছে ফেলা হয়েছে: ${found.title}")
    }

    fun completeWorkout(workoutName: String, durationMinutes: Int = 15): ActionResult {
        val name = workoutName.trim().take(100)
        if (name.isBlank()) return ActionResult(false, "ওয়ার্কআউটের নাম পাওয়া যায়নি।")
        if (durationMinutes !in 1..300) return ActionResult(false, "ওয়ার্কআউটের সময় ১–৩০০ মিনিটের মধ্যে হতে হবে।")
        val session = WorkoutSession(name = name, durationMinutes = durationMinutes)
        _workoutHistory.value = (_workoutHistory.value + session).takeLast(NOVA_LOG_ITEMS)
        _workoutsCompleted.value += 1
        prefs.edit().putInt(KEY_WORKOUT_COUNT, _workoutsCompleted.value).apply()
        saveArray(KEY_WORKOUT_HISTORY, _workoutHistory.value.map { it.toJson() })
        syncDocument("workoutSessions", session.id, session.toJson().toMap())
        return ActionResult(true, "$name-এর $durationMinutes মিনিটের session সম্পন্ন হিসেবে সেভ হয়েছে।")
    }

    fun saveChatHistory(messages: List<ChatMessage>) {
        val recent = messages.takeLast(NOVA_CHAT_MESSAGES)
        saveArray(KEY_CHAT_HISTORY, recent.map { it.toJson() })
    }

    fun loadChatHistory(): List<ChatMessage> = loadArray(KEY_CHAT_HISTORY, ChatMessage::fromJson).takeLast(NOVA_CHAT_MESSAGES)

    fun setWakeWordEnabled(enabled: Boolean) {
        _wakeWordEnabled.value = enabled
        prefs.edit().putBoolean(KEY_WAKE_ENABLED, enabled).apply()
        repositoryScope.launch { runCatching { settingsStore.setWakeWordEnabled(enabled) } }
    }

    fun setDarkMode(enabled: Boolean) {
        _darkMode.value = enabled
        prefs.edit().putBoolean(KEY_DARK_MODE, enabled).apply()
        repositoryScope.launch { runCatching { settingsStore.setDarkMode(enabled) } }
    }

    fun isWakeWordEnabled(): Boolean = _wakeWordEnabled.value
    fun isDarkMode(): Boolean = _darkMode.value
    fun currentUserName(): String = runCatching { FirebaseAuth.getInstance().currentUser?.displayName.orEmpty() }.getOrDefault("")
    fun currentUserEmail(): String = runCatching { FirebaseAuth.getInstance().currentUser?.email.orEmpty() }.getOrDefault("")
    fun isSignedIn(): Boolean = currentUid() != null
    fun hasFirebaseConfiguration(): Boolean = runCatching { FirebaseApp.getApps(appContext).isNotEmpty() }.getOrDefault(false)

    fun snapshotForAi(): JSONObject {
        ensureWaterDate()
        val today = dateKey()
        return JSONObject()
            .put("tasks", JSONArray(_tasks.value.take(30).map { it.toJson() }))
            .put("waterMlToday", _waterMl.value)
            .put("waterTargetMl", _waterTargetMl.value)
            .put("waterEntriesToday", JSONArray(_waterLogs.value.filter { it.date == today }.map { it.toJson() }))
            .put("workoutsCompleted", _workoutsCompleted.value)
            .put("workoutSessionsRecent", JSONArray(_workoutHistory.value.takeLast(10).map { it.toJson() }))
            .put("mealLogsToday", JSONArray(_meals.value.filter { dateKey(it.loggedAt) == today }.map { it.toJson() }))
            .put("mealPlans", JSONArray(_mealPlans.value.take(15).map { it.toJson() }))
            .put("workoutPlans", JSONArray(_workoutPlans.value.take(15).map { it.toJson() }))
            .put("goals", JSONArray(_goals.value.take(30).map { it.toJson() }))
            .put("reminders", JSONArray(_reminders.value.take(30).map { it.toJson() }))
            .put("dailyGoal", _dailyGoal.value)
    }

    fun progressSummary(): JSONObject {
        ensureWaterDate()
        val today = dateKey()
        val completedToday = _tasks.value.count { it.isDone && dateKey(it.completedAt ?: 0L) == today }
        val totalToday = _tasks.value.count {
            dateKey(it.createdAt) == today || (it.isDone && dateKey(it.completedAt ?: 0L) == today)
        }
        val workoutsToday = _workoutHistory.value.count { dateKey(it.completedAt) == today }
        val waterToday = _waterLogs.value.filter { it.date == today }.sumOf { it.amountMl }
        return JSONObject()
            .put("date", today)
            .put("tasksCompletedToday", completedToday)
            .put("tasksTotal", totalToday)
            .put("tasksTotalAllTime", _tasks.value.size)
            .put("workoutsToday", workoutsToday)
            .put("workoutSessionsAllTime", _workoutsCompleted.value)
            .put("waterMlToday", maxOf(_waterMl.value, waterToday))
            .put("waterTargetMl", _waterTargetMl.value)
            .put("mealsLoggedToday", _meals.value.count { dateKey(it.loggedAt) == today })
            .put("activeGoals", _goals.value.count { !it.isComplete })
            .put("completedGoals", _goals.value.count { it.isComplete })
    }

    fun dayWaterTotals(lastDays: Int = 7): List<Pair<String, Int>> {
        val days = lastDays.coerceIn(1, 30)
        return (days - 1 downTo 0).map { offset ->
            val calendar = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, -offset) }
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(calendar.time)
            val label = SimpleDateFormat("EEE", Locale.getDefault()).format(calendar.time)
            label to _waterLogs.value.filter { it.date == date }.sumOf { it.amountMl }
        }
    }

    fun dayWorkoutTotals(lastDays: Int = 7): List<Pair<String, Int>> {
        val days = lastDays.coerceIn(1, 30)
        return (days - 1 downTo 0).map { offset ->
            val calendar = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, -offset) }
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(calendar.time)
            val label = SimpleDateFormat("EEE", Locale.getDefault()).format(calendar.time)
            label to _workoutHistory.value.count { dateKey(it.completedAt) == date }
        }
    }

    fun syncLocalDataToCloud() {
        val uid = currentUid() ?: return
        _tasks.value.forEach { syncDocument("tasks", it.id, it.toJson().toMap()) }
        _goals.value.forEach { syncDocument("goals", it.id, it.toJson().toMap()) }
        _meals.value.forEach { syncDocument("mealLogs", it.id, it.toJson().toMap()) }
        _mealPlans.value.forEach { syncDocument("mealPlans", it.id, it.toJson().toMap()) }
        _workoutPlans.value.forEach { syncDocument("workoutPlans", it.id, it.toJson().toMap()) }
        _reminders.value.forEach { syncDocument("reminders", it.id, it.toJson().toMap()) }
        _workoutHistory.value.forEach { syncDocument("workoutSessions", it.id, it.toJson().toMap()) }
        _waterLogs.value.takeLast(250).forEach { syncDocument("hydrationLogs", it.id, it.toJson().toMap()) }
        runCatching {
            FirebaseFirestore.getInstance().collection("users").document(uid).collection("profile")
                .document("summary").set(
                    mapOf("waterTargetMl" to _waterTargetMl.value, "dailyGoal" to _dailyGoal.value),
                    SetOptions.merge()
                )
        }
    }

    private fun syncTask(task: TaskItem) = syncDocument("tasks", task.id, task.toJson().toMap())
    private fun syncWater(item: WaterLogItem) = syncDocument("hydrationLogs", item.id, item.toJson().toMap())

    private fun syncDocument(collection: String, documentId: String, data: Map<String, Any?>) {
        val uid = currentUid() ?: return
        runCatching {
            FirebaseFirestore.getInstance().collection("users").document(uid)
                .collection(collection).document(documentId).set(data, SetOptions.merge())
        }
    }

    private fun deleteCloudDocument(collection: String, documentId: String) {
        val uid = currentUid() ?: return
        runCatching { FirebaseFirestore.getInstance().collection("users").document(uid).collection(collection).document(documentId).delete() }
    }

    private fun syncProfile() {
        val uid = currentUid() ?: return
        runCatching {
            FirebaseFirestore.getInstance().collection("users").document(uid).collection("profile").document("summary")
                .set(mapOf("waterTargetMl" to _waterTargetMl.value, "dailyGoal" to _dailyGoal.value), SetOptions.merge())
        }
    }

    private fun currentUid(): String? {
        if (!hasFirebaseConfiguration()) return null
        return runCatching { FirebaseAuth.getInstance().currentUser?.uid }.getOrNull()
    }

    private fun ensureWaterDate() {
        if (prefs.getString(KEY_WATER_DATE, "") != dateKey()) {
            prefs.edit().putString(KEY_WATER_DATE, dateKey()).putInt(KEY_WATER_ML, 0).apply()
            _waterMl.value = 0
        }
    }

    private fun loadTodayWater(): Int {
        if (prefs.getString(KEY_WATER_DATE, "") != dateKey()) {
            prefs.edit().putString(KEY_WATER_DATE, dateKey()).putInt(KEY_WATER_ML, 0).apply()
            return 0
        }
        return prefs.getInt(KEY_WATER_ML, 0).coerceAtLeast(0)
    }

    private fun dateKey(timestamp: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(timestamp))

    private fun <T> loadArray(key: String, decoder: (JSONObject) -> T): List<T> = runCatching {
        val array = JSONArray(prefs.getString(key, "[]"))
        (0 until array.length()).mapNotNull { i -> runCatching { decoder(array.getJSONObject(i)) }.getOrNull() }
    }.getOrDefault(emptyList())

    private fun saveArray(key: String, values: List<JSONObject>) {
        val array = JSONArray()
        values.forEach { value -> array.put(value) }
        prefs.edit().putString(key, array.toString()).apply()
    }

    private fun JSONObject.toMap(): Map<String, Any?> = buildMap {
        val iterator = keys()
        while (iterator.hasNext()) {
            val key = iterator.next()
            val value = opt(key)
            put(key, if (value === JSONObject.NULL) null else value)
        }
    }

    companion object {
        private const val KEY_TASKS = "tasks_json"
        private const val KEY_WATER_LOGS = "water_logs_json"
        private const val KEY_WATER_DATE = "water_date"
        private const val KEY_WATER_ML = "water_ml"
        private const val KEY_WATER_TARGET = "water_target_ml"
        private const val KEY_WORKOUT_HISTORY = "workout_history_json"
        private const val KEY_WORKOUT_COUNT = "workouts_completed"
        private const val KEY_MEALS = "meals_json"
        private const val KEY_MEAL_PLANS = "meal_plans_json"
        private const val KEY_WORKOUT_PLANS = "workout_plans_json"
        private const val KEY_REMINDERS = "reminders_json"
        private const val KEY_GOALS = "goals_json"
        private const val KEY_CHAT_HISTORY = "chat_history_json"
        private const val KEY_DAILY_GOAL = "daily_goal"
        private const val KEY_WAKE_ENABLED = "wake_word_enabled"
        private const val KEY_DARK_MODE = "dark_mode"
        private const val NOVA_LOG_ITEMS = 1000
        private const val NOVA_CHAT_MESSAGES = 120
        const val DEFAULT_WATER_TARGET = 2000
    }
}
