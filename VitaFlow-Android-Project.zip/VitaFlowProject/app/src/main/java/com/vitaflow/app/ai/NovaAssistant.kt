package com.vitaflow.app.ai

import com.vitaflow.app.data.VitaFlowRepository
import com.vitaflow.app.model.ActionResult
import com.vitaflow.app.model.ChatMessage
import com.google.firebase.Firebase
import com.google.firebase.ai.type.GenerativeBackend
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Firebase AI Logic-powered assistant. It never invokes arbitrary Kotlin or arbitrary URLs. */
class NovaAssistant(private val repository: VitaFlowRepository) {
    private val actions = ActionRegistry(repository)
    private val localRouter = LocalIntentRouter(repository)

    suspend fun reply(userText: String, recentHistory: List<ChatMessage>): String = withContext(Dispatchers.IO) {
        // The common app commands still work offline without inventing AI answers.
        localRouter.tryHandle(userText)?.let { return@withContext it.message }
        if (!repository.hasFirebaseConfiguration()) {
            return@withContext "Nova-এর সাধারণ AI chat চালাতে VitaFlow-র Firebase সেটআপ দরকার। তবে task, পানি, goal, meal, workout ও progress-এর কিছু নির্দিষ্ট command এখনই লোকালভাবে কাজ করে। Firebase সেটআপের নির্দেশনা ZIP-এর FIREBASE_SETUP_BN.md ফাইলে আছে।"
        }

        try {
            val model = Firebase.ai(backend = GenerativeBackend.googleAI())
                .generativeModel("gemini-3.8-flash")
            val historyText = recentHistory.takeLast(10).joinToString("\n") {
                val role = if (it.fromUser) "USER" else "NOVA"
                "$role: ${it.text.take(700)}"
            }
            val prompt = """
                You are Nova, the friendly, careful assistant inside VitaFlow, a fitness and daily-routine Android app.
                Respond in the user's language and tone: Bangla, English, or Banglish. Answer ordinary questions normally.
                You may control the app ONLY by returning an action listed in the allow-list below. Actions are executed by a strict Kotlin registry; never invent success.

                IMPORTANT TRUTH AND SAFETY RULES
                - Use APP_STATE as the only source for the user's saved app data. Never invent progress, meal logs, tasks, workouts, or reminders.
                - Never say an action succeeded until the returned action result says it succeeded.
                - If a required value is missing, or a target/title/time is ambiguous, return CLARIFY and ask one short question. Do not guess.
                - You may ask to create up to 3 separate actions for a clear multi-action user request. Do not duplicate an action.
                - No delete action is available. Do not claim to delete data.
                - Do not diagnose medical conditions. For medical concerns, advise talking to a qualified health professional.
                - Do not propose extreme exercise, severe food restriction, dehydration, or rapid body-change plans. Keep fitness advice age-appropriate and sustainable.
                - Food calorie values are estimates, not clinical measurements. Don't guess calories for a logged meal unless the user supplies a value.
                - Time for CREATE_REMINDER must be 24-hour HH:mm, e.g. 09:30. Only create it if the user clearly states a time.
                - Do not ask for or expose secrets, API keys, or tokens.

                Return exactly one JSON object with no Markdown or surrounding text.
                Normal chat: {"kind":"CHAT","message":"response"}
                Missing information: {"kind":"CLARIFY","message":"one concise question"}
                One app operation: {"kind":"ACTION","name":"ACTION_NAME","args":{...}}
                Multiple app operations (maximum 3): {"kind":"ACTIONS","actions":[{"name":"ACTION_NAME","args":{...}}],"message":"optional brief intro"}

                ALLOWED ACTIONS (no other names are permitted)
                - CREATE_TASK: {"title":"task name"}
                - COMPLETE_TASK: {"title":"unique existing task title"}
                - LOG_WATER_INTAKE: {"amountMl": integer, one entry 50–2000}
                - SET_HYDRATION_TARGET: {"amountMl": integer, 250–10000}
                - SET_DAILY_GOAL: {"goal":"short goal text"}
                - ADD_GOAL: {"title":"goal title","targetValue":integer optional default 1,"unit":"unit text" optional default times}
                - COMPLETE_GOAL: {"title":"unique existing goal title"}
                - COMPLETE_WORKOUT: {"workoutName":"workout name","durationMinutes":integer optional default 15}
                - LOG_MEAL: {"name":"meal/food name","mealType":"Breakfast|Lunch|Dinner|Snack" optional,"calories":integer optional only when user supplies it,"note":"optional"}
                - CREATE_MEAL_PLAN: {"title":"plan title","breakfast":"meal idea","lunch":"meal idea","dinner":"meal idea","snack":"optional snack idea","notes":"optional notes"}. Do not prescribe extreme restrictions or claim medical nutrition precision.
                - CREATE_WORKOUT_PLAN: {"title":"plan title","focus":"focus","durationMinutes":integer 1–300,"exercises":"exercise/activity list as text"}. Keep plans moderate and adaptable; include rest and advise stopping for pain/dizziness.
                - CREATE_REMINDER: {"title":"reminder text","time":"HH:mm"}
                - SET_REMINDER_ENABLED: {"title":"unique reminder title","enabled":boolean}
                - GET_PROGRESS: {}
                - GET_TASKS: {}
                - GET_HYDRATION: {}
                - GET_GOALS: {}
                - GET_REMINDERS: {}
                - GET_MEALS: {}
                - GET_MEAL_PLANS: {}
                - GET_WORKOUT_HISTORY: {}
                - GET_WORKOUT_LIBRARY: {}
                - GET_WORKOUT_PLANS: {}

                APP_STATE: ${repository.snapshotForAi()}
                RECENT_CONVERSATION:
                $historyText
                USER_MESSAGE:
                ${userText.take(2000)}
            """.trimIndent()

            val generated = model.generateContent(prompt).text.orEmpty().trim()
            val json = extractJson(generated)
            if (json == null) return@withContext generated.ifBlank { "দুঃখিত, Nova এবার উত্তর তৈরি করতে পারেনি। আবার চেষ্টা করো।" }

            when (json.optString("kind").uppercase()) {
                "CHAT", "CLARIFY" -> json.optString("message").ifBlank { "কীভাবে সাহায্য করতে পারি?" }
                "ACTION" -> runAction(json.optString("name"), json.optJSONObject("args") ?: JSONObject()).message
                "ACTIONS" -> runMultipleActions(json)
                else -> json.optString("message").ifBlank { "দুঃখিত, Nova-এর উত্তরটি বুঝতে পারিনি।" }
            }
        } catch (error: Exception) {
            val detail = error.message.orEmpty()
            when {
                detail.contains("App Check", ignoreCase = true) || detail.contains("attestation", ignoreCase = true) ->
                    "Firebase App Check সেটআপ সম্পূর্ণ হয়নি। Debug token Firebase Console → App Check-এ register করে আবার চেষ্টা করো।"
                detail.contains("PERMISSION_DENIED", ignoreCase = true) || detail.contains("disabled", ignoreCase = true) || detail.contains("not been used", ignoreCase = true) ->
                    "Firebase AI Logic চালু বা অনুমোদিত নয়। Firebase Console → AI Services → AI Logic-এর সেটআপ এবং App Check status যাচাই করো।"
                detail.contains("quota", ignoreCase = true) || detail.contains("429") ->
                    "Nova-এর AI ব্যবহারের সীমা আপাতত শেষ হয়েছে। কিছুক্ষণ পরে চেষ্টা করো এবং Firebase usage/limits যাচাই করো।"
                else -> "Nova-এর সঙ্গে সংযোগ করা যায়নি। ইন্টারনেট, Firebase configuration ও AI Logic সেটআপ যাচাই করে আবার চেষ্টা করো।"
            }
        }
    }

    private fun runAction(name: String, args: JSONObject): ActionResult = actions.execute(name, args)

    private fun runMultipleActions(json: JSONObject): String {
        val array: JSONArray = json.optJSONArray("actions") ?: return "Nova-এর action তালিকাটি পড়তে পারিনি; কোনো কাজ চালানো হয়নি।"
        if (array.length() !in 1..3) return "একবারে ১–৩টি অনুমোদিত action-ই চালানো যায়; কোনো কাজ চালানো হয়নি।"
        val results = (0 until array.length()).map { index ->
            val item = array.optJSONObject(index) ?: return@map ActionResult(false, "Action ${index + 1}-এর format সঠিক নয়।")
            runAction(item.optString("name"), item.optJSONObject("args") ?: JSONObject())
        }
        val intro = json.optString("message").trim()
        return buildString {
            if (intro.isNotBlank()) append(intro.take(180)).append('\n')
            results.forEachIndexed { index, result ->
                append(if (result.success) "✓ " else "! ")
                append(result.message)
                if (index != results.lastIndex) append('\n')
            }
        }
    }

    private fun extractJson(raw: String): JSONObject? {
        runCatching { JSONObject(raw) }.getOrNull()?.let { return it }
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start >= 0 && end > start) return runCatching { JSONObject(raw.substring(start, end + 1)) }.getOrNull()
        return null
    }
}
