package com.vitaflow.app.reminders

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.vitaflow.app.MainActivity
import com.vitaflow.app.R
import com.vitaflow.app.data.VitaFlowRepository

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(ReminderScheduler.EXTRA_ID).orEmpty()
        val title = intent.getStringExtra(ReminderScheduler.EXTRA_TITLE).orEmpty().ifBlank { "VitaFlow reminder" }
        createChannel(context)
        val openApp = PendingIntent.getActivity(
            context,
            (id.hashCode() and 0x7fffffff).coerceAtLeast(2),
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText("তোমার VitaFlow reminder")
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify((id.hashCode() and 0x7fffffff).coerceAtLeast(1), notification) }

        // Daily reminders schedule their next occurrence only after the current alarm fires.
        val reminder = VitaFlowRepository(context).reminders.value.firstOrNull { it.id == id && it.enabled }
        if (reminder != null && reminder.repeatDaily) ReminderScheduler.schedule(context, reminder)
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val channel = NotificationChannel(CHANNEL_ID, "VitaFlow reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Daily task, hydration and routine reminders"
            }
            manager.createNotificationChannel(channel)
        }
    }

    companion object { private const val CHANNEL_ID = "vitaflow_daily_reminders" }
}

class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val repository = VitaFlowRepository(context)
        repository.reminders.value.filter { it.enabled }.forEach { ReminderScheduler.schedule(context, it) }
    }
}
