package com.vitaflow.app.voice

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Foreground-only voice controller. Wake phrase recognition uses Android SpeechRecognizer,
 * which may rely on the device's speech service/network and is not an offline hotword engine.
 */
class VoiceController(context: Context) : TextToSpeech.OnInitListener {
    private val activityContext = context
    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = TextToSpeech(context, this)
    private var wakeEnabled = false
    private var wakeCallback: ((String) -> Unit)? = null
    private var oneShotCallback: ((String) -> Unit)? = null
    private var oneShotError: ((String) -> Unit)? = null
    private var isOneShot = false
    private var ttsReady = false
    private var listening = false

    private val restartWakeRunnable = Runnable { if (wakeEnabled && !listening) beginWakeCapture() }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val systemLocale = Locale.getDefault()
            tts?.language = systemLocale
        }
    }

    fun startWakeWord(onWake: (command: String) -> Unit) {
        wakeEnabled = true
        wakeCallback = onWake
        if (!SpeechRecognizer.isRecognitionAvailable(activityContext)) return
        ensureRecognizer()
        if (!listening) beginWakeCapture()
    }

    fun stopWakeWord() {
        wakeEnabled = false
        mainHandler.removeCallbacks(restartWakeRunnable)
        // Also stop a one-shot voice request when the activity leaves the foreground.
        // Clear callbacks before cancel(), because SpeechRecognizer may deliver ERROR_CLIENT.
        oneShotCallback = null
        oneShotError = null
        isOneShot = false
        runCatching { recognizer?.cancel() }
        listening = false
    }

    fun listenOnce(onResult: (String) -> Unit, onError: (String) -> Unit = {}) {
        wakeEnabled = false
        isOneShot = true
        oneShotCallback = onResult
        oneShotError = onError
        if (!SpeechRecognizer.isRecognitionAvailable(activityContext)) {
            isOneShot = false
            onError("এই ডিভাইসে speech recognition পাওয়া যায়নি।")
            return
        }
        ensureRecognizer()
        runCatching { recognizer?.cancel() }
        listening = false
        startRecognition(oneShotListener)
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        val engine = tts
        if (!ttsReady || engine == null) {
            onDone?.invoke()
            return
        }
        val utteranceId = "vitaflow-${System.currentTimeMillis()}"
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) { mainHandler.post { onDone?.invoke() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { mainHandler.post { onDone?.invoke() } }
            override fun onError(utteranceId: String?, errorCode: Int) { mainHandler.post { onDone?.invoke() } }
        })
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun destroy() {
        wakeEnabled = false
        mainHandler.removeCallbacksAndMessages(null)
        runCatching { recognizer?.destroy() }
        recognizer = null
        runCatching { tts?.stop(); tts?.shutdown() }
        tts = null
    }

    private fun ensureRecognizer() {
        if (recognizer != null) return
        recognizer = SpeechRecognizer.createSpeechRecognizer(activityContext)
    }

    private fun beginWakeCapture() {
        if (!wakeEnabled || listening || !SpeechRecognizer.isRecognitionAvailable(activityContext)) return
        ensureRecognizer()
        startRecognition(wakeListener)
    }

    private fun startRecognition(listener: RecognitionListener) {
        val recognizerNow = recognizer ?: return
        recognizerNow.setRecognitionListener(listener)
        listening = true
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_NOVA_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, activityContext.packageName)
        }
        runCatching { recognizerNow.startListening(intent) }.onFailure {
            listening = false
            if (isOneShot) {
                isOneShot = false
                oneShotError?.invoke("মাইক্রোফোন শুরু করা যায়নি। অনুমতি ও speech service যাচাই করো।")
            } else if (wakeEnabled) {
                mainHandler.postDelayed(restartWakeRunnable, 1200L)
            }
        }
    }

    private val wakeListener = object : RecognitionListener by EmptyRecognitionListener() {
        override fun onResults(results: android.os.Bundle?) {
            listening = false
            val raw = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            val lowered = raw.lowercase(Locale.ROOT)
            val wakeTokens = listOf("hey max", "hey marks", "hey macks", "হে ম্যাক্স", "হেই ম্যাক্স", "হে ম্যাক্স")
            val matched = wakeTokens.firstOrNull { lowered.contains(it) }
            if (matched != null) {
                wakeEnabled = false
                val command = lowered.substringAfter(matched, "").trim(' ', ',', '.', '!', '?', ':', ';')
                wakeCallback?.invoke(command)
            } else if (wakeEnabled) {
                mainHandler.postDelayed(restartWakeRunnable, 500L)
            }
        }

        override fun onError(error: Int) {
            listening = false
            if (wakeEnabled) mainHandler.postDelayed(restartWakeRunnable, if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1300L else 700L)
        }

        override fun onReadyForSpeech(params: android.os.Bundle?) = Unit
        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = Unit
        override fun onPartialResults(partialResults: android.os.Bundle?) = Unit
        override fun onEvent(eventType: Int, params: android.os.Bundle?) = Unit
    }

    private val oneShotListener = object : RecognitionListener by EmptyRecognitionListener() {
        override fun onResults(results: android.os.Bundle?) {
            listening = false
            isOneShot = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (text.isBlank()) oneShotError?.invoke("কথাটি বুঝতে পারিনি। আবার বলো।") else oneShotCallback?.invoke(text)
            oneShotCallback = null
            oneShotError = null
        }

        override fun onError(error: Int) {
            listening = false
            isOneShot = false
            val message = when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "মাইক্রোফোন ব্যবহারের অনুমতি নেই।"
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কথাটি বুঝতে পারিনি। আবার চেষ্টা করো।"
                else -> "Speech recognition-এ সমস্যা হয়েছে। আবার চেষ্টা করো।"
            }
            oneShotError?.invoke(message)
            oneShotCallback = null
            oneShotError = null
        }

        override fun onReadyForSpeech(params: android.os.Bundle?) = Unit
        override fun onBeginningOfSpeech() = Unit
        override fun onRmsChanged(rmsdB: Float) = Unit
        override fun onBufferReceived(buffer: ByteArray?) = Unit
        override fun onEndOfSpeech() = Unit
        override fun onPartialResults(partialResults: android.os.Bundle?) = Unit
        override fun onEvent(eventType: Int, params: android.os.Bundle?) = Unit
    }
}

/** No-op listener base to keep the actual listeners focused on the callbacks we handle. */
private open class EmptyRecognitionListener : RecognitionListener {
    override fun onReadyForSpeech(params: android.os.Bundle?) = Unit
    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() = Unit
    override fun onError(error: Int) = Unit
    override fun onResults(results: android.os.Bundle?) = Unit
    override fun onPartialResults(partialResults: android.os.Bundle?) = Unit
    override fun onEvent(eventType: Int, params: android.os.Bundle?) = Unit
}
