package com.vitaflow.app.ai

import com.vitaflow.app.data.VitaFlowRepository
import com.vitaflow.app.model.ActionResult
import java.util.Locale

/** Small deterministic fallback for common explicit commands when Firebase AI is not configured. */
class LocalIntentRouter(private val repository: VitaFlowRepository) {
    fun tryHandle(rawText: String): ActionResult? {
        val text = rawText.trim()
        if (text.isBlank()) return null
        val normalizedDigits = text.map { ch ->
            when (ch) {
                '০' -> '0'; '১' -> '1'; '২' -> '2'; '৩' -> '3'; '৪' -> '4'
                '৫' -> '5'; '৬' -> '6'; '৭' -> '7'; '৮' -> '8'; '৯' -> '9'
                else -> ch
            }
        }.joinToString("")
        val normalizedLower = normalizedDigits.lowercase(Locale.ROOT)

        if (listOf("show my progress", "get progress", "আমার অগ্রগতি", "progress দেখাও", "অগ্রগতি দেখাও").any { normalizedLower.contains(it) }) {
            val p = repository.progressSummary()
            return ActionResult(true, "সেভ করা তথ্য অনুযায়ী:\n• আজকের task: ${p.optInt("tasksCompletedToday")} / ${p.optInt("tasksTotal")}\n• পানি: ${p.optInt("waterMlToday")} / ${p.optInt("waterTargetMl")} ml\n• আজ workout: ${p.optInt("workoutsToday")}টি")
        }
        if (listOf("show my tasks", "list my tasks", "আমার টাস্ক", "কাজের তালিকা", "task list").any { normalizedLower.contains(it) }) {
            val items = repository.tasks.value.take(12)
            return ActionResult(true, if (items.isEmpty()) "এখনো কোনো task নেই।" else items.joinToString("\n") { "${if (it.isDone) "✓" else "•"} ${it.title}" })
        }

        val waterAmount = Regex("(?i)(\\d{1,5})\\s*(?:ml|millilit(?:er|re)s?|মিলি(?:লিটার)?|মিলিলিটার)").find(normalizedDigits)
        val mentionsWater = listOf("water", "পানি", "জল", "hydration", "পানির").any { normalizedLower.contains(it) }
        if (waterAmount != null && mentionsWater && listOf("log", "add", "drink", "পানি", "জল", "লগ", "যোগ", "খেয়েছি", "খেলাম").any { normalizedLower.contains(it) }) {
            return repository.addWater(waterAmount.groupValues[1].toIntOrNull() ?: -1)
        }

        val targetMatch = Regex("(?i)(?:water\\s*(?:target|goal)|hydration\\s*target|পানির\\s*(?:লক্ষ্য|টার্গেট)|জল\\s*লক্ষ্য)[^0-9]{0,12}(\\d{2,5})").find(normalizedLower)
        if (targetMatch != null) return repository.setWaterTarget(targetMatch.groupValues[1].toIntOrNull() ?: -1)

        val addTask = Regex("(?i)^(?:please\\s+)?(?:create|add|make|new)\\s+(?:a\\s+)?task\\s*[:\\-]?\\s*(.+)$").find(text)
            ?: Regex("(?i)^(?:টাস্ক|task)\\s*(?:যোগ|add|তৈরি)\\s*(?:করো|করুন|কর|:)?\\s*[:\\-]?\\s*(.+)$").find(text)
            ?: Regex("(?i)^কাজ\\s*(?:যোগ|তৈরি)\\s*(?:করো|করুন|কর)?\\s*[:\\-]?\\s*(.+)$").find(text)
        if (addTask != null) return repository.addTask(addTask.groupValues[1].trim().trim('"', '\''))

        val completeTask = Regex("(?i)^(?:complete|finish|done|mark complete)\\s+(?:the\\s+)?task\\s*[:\\-]?\\s*(.+)$").find(text)
            ?: Regex("(?i)^(?:task|টাস্ক)\\s*(?:complete|সম্পন্ন|শেষ)\\s*[:\\-]?\\s*(.+)$").find(text)
            ?: Regex("(?i)^কাজ\\s*(?:শেষ|সম্পন্ন)\\s*(?:করো|করুন|কর)?\\s*[:\\-]?\\s*(.+)$").find(text)
        if (completeTask != null) return repository.completeTask(completeTask.groupValues[1].trim().trim('"', '\''))

        val logMeal = Regex("(?i)^(?:log|add|record)\\s+(?:a\\s+)?meal\\s*[:\\-]?\\s*(.+)$").find(text)
            ?: Regex("(?i)^(?:খাবার|meal)\\s*(?:লগ|যোগ|add|record)\\s*(?:করো|করুন|কর)?\\s*[:\\-]?\\s*(.+)$").find(text)
        if (logMeal != null) return repository.addMeal(logMeal.groupValues[1].trim())

        val addGoal = Regex("(?i)^(?:add|create|set)\\s+(?:a\\s+)?goal\\s*[:\\-]?\\s*(.+)$").find(text)
            ?: Regex("(?i)^goal\\s*(?:যোগ|add|তৈরি)\\s*[:\\-]?\\s*(.+)$").find(text)
        if (addGoal != null) return repository.addGoal(addGoal.groupValues[1].trim())

        val setDailyGoal = Regex("(?i)^(?:set|change)\\s+(?:my\\s+)?daily goal\\s*[:\\-]?\\s*(.+)$").find(text)
            ?: Regex("(?i)^(?:আজকের|দৈনিক)\\s*লক্ষ্য\\s*(?:সেট|বদল|পরিবর্তন)\\s*(?:করো|করুন)?\\s*[:\\-]?\\s*(.+)$").find(text)
        if (setDailyGoal != null) return repository.setDailyGoal(setDailyGoal.groupValues[1].trim())

        val completeWorkout = Regex("(?i)^(?:complete|log|finish)\\s+(?:the\\s+)?workout\\s*[:\\-]?\\s*(.+)$").find(text)
        if (completeWorkout != null) return repository.completeWorkout(completeWorkout.groupValues[1].trim())
        return null
    }
}
