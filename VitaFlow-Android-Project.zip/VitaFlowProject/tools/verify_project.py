#!/usr/bin/env python3
"""Offline static checks for the VitaFlow source archive; not a replacement for Gradle build/tests."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
required = [
    "settings.gradle.kts",
    "build.gradle.kts",
    "gradle.properties",
    "gradle/wrapper/gradle-wrapper.properties",
    "gradle/wrapper/gradle-wrapper.jar",
    "gradlew",
    "gradlew.bat",
    "app/build.gradle.kts",
    "app/proguard-rules.pro",
    "app/google-services.json.example.txt",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/vitaflow/app/MainActivity.kt",
    "app/src/main/java/com/vitaflow/app/VitaFlowApplication.kt",
    "app/src/main/java/com/vitaflow/app/ai/NovaAssistant.kt",
    "app/src/main/java/com/vitaflow/app/ai/ActionRegistry.kt",
    "app/src/main/java/com/vitaflow/app/ai/LocalIntentRouter.kt",
    "app/src/main/java/com/vitaflow/app/data/VitaFlowRepository.kt",
    "app/src/main/java/com/vitaflow/app/data/VitaFlowSettingsStore.kt",
    "app/src/main/java/com/vitaflow/app/model/VitaFlowModels.kt",
    "app/src/main/java/com/vitaflow/app/reminders/ReminderScheduler.kt",
    "app/src/main/java/com/vitaflow/app/reminders/ReminderReceiver.kt",
    "app/src/main/java/com/vitaflow/app/ui/VitaFlowApp.kt",
    "app/src/main/java/com/vitaflow/app/ui/VitaFlowTheme.kt",
    "app/src/main/java/com/vitaflow/app/voice/VoiceController.kt",
    "app/src/debug/java/com/vitaflow/app/AppCheckBootstrap.kt",
    "app/src/release/java/com/vitaflow/app/AppCheckBootstrap.kt",
    "app/src/main/res/drawable/ic_vitaflow.xml",
    "app/src/main/res/drawable/ic_notification.xml",
    "firebase/firestore.rules",
    "FIREBASE_SETUP_BN.md",
    "README.md",
    "BUILD_STATUS.txt",
    "docs/PROJECT_SCOPE_BN.md",
]
errors = []
for name in required:
    if not (ROOT / name).is_file():
        errors.append(f"Missing required file: {name}")

xml_files = list((ROOT / "app/src/main").rglob("*.xml"))
for path in xml_files:
    try:
        ET.parse(path)
    except ET.ParseError as exc:
        errors.append(f"Invalid XML {path.relative_to(ROOT)}: {exc}")

source_files = list((ROOT / "app/src").rglob("*.kt"))
for path in source_files:
    text = path.read_text(encoding="utf-8")
    # Lightweight delimiter balance check after stripping comments and string literals.
    scrubbed = re.sub(r'""".*?"""', '""', text, flags=re.S)
    scrubbed = re.sub(r'"(?:\\.|[^"\\])*"', '""', scrubbed)
    scrubbed = re.sub(r"'(?:\\.|[^'\\])*'", "''", scrubbed)
    scrubbed = re.sub(r"/\*.*?\*/", "", scrubbed, flags=re.S)
    scrubbed = re.sub(r"//[^\n]*", "", scrubbed)
    for left, right in [("(", ")"), ("{", "}"), ("[", "]")]:
        count = 0
        for ch in scrubbed:
            if ch == left:
                count += 1
            elif ch == right:
                count -= 1
                if count < 0:
                    errors.append(f"Unbalanced {left}{right} in {path.relative_to(ROOT)}")
                    break
        if count != 0:
            errors.append(f"Unbalanced {left}{right} in {path.relative_to(ROOT)} (balance={count})")

manifest = (ROOT / "app/src/main/AndroidManifest.xml")
if manifest.exists():
    root = ET.parse(manifest).getroot()
    ns = "{http://schemas.android.com/apk/res/android}"
    activities = [node for node in root.findall("application/activity") if node.attrib.get(ns + "exported") == "true"]
    if not activities:
        errors.append("No exported launcher activity found in AndroidManifest.xml")

gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8") if (ROOT / "app/build.gradle.kts").exists() else ""
if 'applicationId = "com.vitaflow.app"' not in gradle:
    errors.append("Unexpected applicationId: expected com.vitaflow.app")
if "firebase-ai" not in gradle:
    errors.append("Firebase AI Logic dependency missing from app/build.gradle.kts")
if "com.vitaflow.app" not in (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8") and "applicationId = \"com.vitaflow.app\"" not in gradle:
    errors.append("VitaFlow package/application ID does not match expected com.vitaflow.app")
rules = (ROOT / "firebase/firestore.rules").read_text(encoding="utf-8") if (ROOT / "firebase/firestore.rules").exists() else ""
if "request.auth.uid == uid" not in rules:
    errors.append("Firestore rules do not visibly enforce UID isolation")
if 'implementation("com.google.firebase:firebase-ai")' not in gradle:
    errors.append("Firebase AI Logic dependency line is missing")
if "google-services.json" not in (ROOT / ".gitignore").read_text(encoding="utf-8"):
    errors.append(".gitignore should exclude the private Firebase config file")
if (ROOT / "app/google-services.json").exists():
    print("Note: app/google-services.json is present; make sure it belongs to the independent VitaFlow Firebase project.")
else:
    print("Note: app/google-services.json is absent (expected until the owner configures Firebase).")

if errors:
    print("VitaFlow static verification FAILED:")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)
print(f"VitaFlow static verification passed: {len(required)} required-file checks, {len(xml_files)} XML files, {len(source_files)} Kotlin files.")
print("This is a static check only; it does not compile Android/Kotlin code or validate live Firebase behavior.")
