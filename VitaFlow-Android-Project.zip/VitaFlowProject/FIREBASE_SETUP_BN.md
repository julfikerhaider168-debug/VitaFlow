# VitaFlow — Firebase সেটআপ ও প্রয়োজনীয় ফাইল সংগ্রহ

এই গাইডটি **VitaFlow**-এর জন্য। MissionMe-র Firebase project, `google-services.json`, OAuth ID বা signing config ব্যবহার করবে না; VitaFlow-র জন্য নিজস্ব Firebase project তৈরি করবে।

## তোমাকে যেগুলো সংগ্রহ/সেট করতে হবে

1. **Android Studio** (সাম্প্রতিক stable version) এবং **Android SDK Platform 36**। Android Studio-তে JDK 17 ব্যবহার করবে।
2. **VitaFlow-এর `google-services.json`** — Firebase Console থেকে download করে এই প্রজেক্টে `app/google-services.json` নামে রাখবে। `app/google-services.json.example.txt` আসল config নয়।
3. **Google Sign-In সেটিংস** — VitaFlow Android app-এর application ID হবে `com.vitaflow.app`; Firebase Authentication-এ Google provider enable করতে হবে। তোমার build key-এর SHA-1/SHA-256 fingerprint Firebase project settings-এ যোগ করতে হবে।
4. **Firebase AI Logic** — Firebase Console-এ AI Services → AI Logic খুলে Gemini Developer API setup সম্পন্ন করবে। APK/source code-এ আলাদা Gemini API key hard-code করবে না।
5. **App Check debug token** — প্রথম debug build চালানোর পরে Logcat-এ Firebase App Check-এর debug token দেখা গেলে সেটি শুধু Firebase Console → App Check → Debug tokens-এ register করবে। Token কাউকে পাঠাবে না এবং প্রকাশ্যে রাখবে না।
6. **Cloud Firestore ও Rules** — Firestore database তৈরি করে `firebase/firestore.rules` deploy করবে। Rules না দিয়ে পরীক্ষা করার জন্য database public করে দেবে না।
7. **ফোনে test করার অনুমতি** — প্রথমবার voice assistant ব্যবহার করলে microphone permission দেবে; reminder notification দেখাতে Android 13+ এ notification permission দিতে হবে।

## Firebase project তৈরি করার ধাপ

1. Firebase Console-এ একটি নতুন project তৈরি করো; নাম `VitaFlow` হতে পারে।
2. Android app যোগ করো, package/application ID-তে একদম `com.vitaflow.app` দাও।
3. Android Studio-এর Gradle signing report থেকে debug SHA-1/SHA-256 বের করো। Android Studio Terminal-এ project folder থেকে `./gradlew signingReport` চালাতে পারো (Windows: `gradlew.bat signingReport`)। Gradle প্রথমবার download না থাকলে internet লাগবে।
4. Firebase Console → Project settings → Your apps-এ fingerprint যোগ করো; তারপর `google-services.json` download করে project-এর `app/` folder-এ রাখো।
5. Authentication → Sign-in method/Providers থেকে **Google** enable করো। Google sign-in-এর জন্য Firebase-generated Web client ID/`default_web_client_id` প্রয়োজন; সঠিক `google-services.json` Gradle sync-এর সময় সংশ্লিষ্ট resource তৈরি করবে।
6. AI Services → AI Logic → Get started-এ গিয়ে **Gemini Developer API** সেটআপ সম্পন্ন করো। Firebase AI Logic ব্যবহারে App Check configuration-ও ঠিক থাকতে হবে।
7. Build চালিয়ে App Check debug token তৈরি হলে সেটি register করো। শুধুমাত্র নিজের test device-এর debug token ব্যবহার করবে।
8. Cloud Firestore তৈরি করে Rules পেজে `firebase/firestore.rules`-এর contents publish করো। Rules শুধু signed-in user-কে তার নিজের `users/{uid}/...` path-এ access দেয়।

## Build করে APK বের করার নিয়ম

1. ZIP extract করে Android Studio-তে সেই folder open করো যেখানে `settings.gradle.kts` আছে (সাধারণত `VitaFlowProject/`)।
2. SDK Manager থেকে Android SDK Platform 36 install হয়েছে নিশ্চিত করো; Gradle sync complete হতে দাও। First sync-এ internet দরকার হবে।
3. `app/google-services.json` যোগ করা এবং Firebase settings complete করার পর Run করে app খুলে দেখো।
4. Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**। অথবা project terminal-এ `./gradlew assembleDebug` চালাও (Windows-এ `gradlew.bat assembleDebug`)।
5. Build সফল হলে debug APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ থাকবে। Build ব্যর্থ হলে প্রথম `Caused by:` বা `e:` error থেকে debugging শুরু করো; শুধু APK filename তৈরি হয়েছে বলে build success ধরে নেবে না।

## কী পরীক্ষা করবে

- App config ছাড়া dashboard, tasks, hydration, goals এবং local history খোলে কি না।
- Google Sign-In success/failure message সঠিক কি না।
- Nova সাধারণ chat, task/water/goal/meal/workout command চালায় কি না এবং অস্পষ্ট input-এ clarification চায় কি না।
- App Check/AI Logic চালু না থাকলে user-friendly error দেখায় কি না।
- Voice input, spoken reply এবং foreground `Hey Nova` phrase তোমার ফোনে কাজ করে কি না। Android speech service-এর ভাষা ও accuracy ফোনভেদে আলাদা হতে পারে।
- Reminder permission allow করার পরে notification দেখা যায় কি না; Android battery policy alarm delay করতে পারে।
- Sign-in করার পর data শুধু নিজের UID path-এ Firestore-এ লেখা হয় কি না।

## নিরাপত্তা ও খরচ

- `google-services.json` সাধারণ Firebase app configuration file, তবে project files-এর সঙ্গে প্রকাশ্যে share না করাই ভালো। Private keys/service account JSON/keystore passwords/debug token কখনো share করবে না।
- Gemini API key APK-তে ঢোকাবে না। Firebase Console-এ usage/quota দেখবে এবং প্রযোজ্য হলে budget alert সেট করবে।
- Local records এই ডিভাইসে থাকে; বর্তমান source cloud write সমর্থন করে, কিন্তু full cloud restore/merge implementation নেই।
- Nova-এর workout/nutrition suggestion সাধারণ তথ্য; কোনো চিকিৎসা নির্ণয় বা চিকিৎসকের পরামর্শের বিকল্প নয়।
