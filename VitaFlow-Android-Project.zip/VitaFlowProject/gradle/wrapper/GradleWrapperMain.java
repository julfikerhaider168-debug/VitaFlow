package org.gradle.wrapper;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Small bootstrap launcher for this starter archive. It downloads the official Gradle distribution
 * over HTTPS and executes it; it does not implement Gradle's internal wrapper protocol.
 */
public final class GradleWrapperMain {
    private GradleWrapperMain() {}

    public static void main(String[] args) throws Exception {
        Path projectDir = Paths.get("").toAbsolutePath().normalize();
        Path propertiesFile = projectDir.resolve("gradle/wrapper/gradle-wrapper.properties");
        if (!Files.exists(propertiesFile)) {
            throw new IllegalStateException("Run gradlew from the Fitora project directory; missing " + propertiesFile);
        }
        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(propertiesFile)) { properties.load(in); }
        String distributionUrl = properties.getProperty("distributionUrl");
        if (distributionUrl == null || !distributionUrl.startsWith("https://")) {
            throw new IllegalStateException("A valid HTTPS distributionUrl is required in gradle-wrapper.properties.");
        }
        String fileName = Paths.get(URI.create(distributionUrl).getPath()).getFileName().toString();
        String distributionName = fileName.replaceAll("-bin\\.zip$", "").replaceAll("-all\\.zip$", "");
        String gradleUserHome = System.getenv("GRADLE_USER_HOME");
        Path userHome = gradleUserHome == null || gradleUserHome.trim().isEmpty()
                ? Paths.get(System.getProperty("user.home"), ".gradle") : Paths.get(gradleUserHome);
        Path cacheDir = userHome.resolve("wrapper/dists/fitora-bootstrap").resolve(distributionName);
        Path gradleHome = cacheDir.resolve(distributionName);
        boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");
        Path gradleExecutable = gradleHome.resolve("bin").resolve(windows ? "gradle.bat" : "gradle");

        if (!Files.exists(gradleExecutable)) {
            Files.createDirectories(cacheDir);
            Path zipFile = cacheDir.resolve(fileName + ".download");
            Path tempFile = cacheDir.resolve("distribution.zip");
            System.out.println("Downloading official Gradle distribution: " + distributionUrl);
            download(distributionUrl, tempFile);
            if (Files.exists(gradleHome)) deleteTree(gradleHome);
            extractSafely(tempFile, cacheDir);
            Files.deleteIfExists(tempFile);
            if (!Files.exists(gradleExecutable)) {
                throw new IOException("Gradle extracted, but executable was not found at " + gradleExecutable);
            }
            if (!windows) gradleExecutable.toFile().setExecutable(true);
        }

        java.util.List<String> command = new java.util.ArrayList<>();
        if (windows) {
            command.add("cmd.exe"); command.add("/c"); command.add(gradleExecutable.toString());
        } else {
            command.add(gradleExecutable.toString());
        }
        for (String arg : args) command.add(arg);
        Process process = new ProcessBuilder(command).directory(projectDir.toFile()).inheritIO().start();
        int exitCode = process.waitFor();
        System.exit(exitCode);
    }

    private static void download(String source, Path destination) throws IOException {
        URL url = URI.create(source).toURL();
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(120000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("User-Agent", "Fitora-Gradle-Bootstrap/1.0");
        try {
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new IOException("Gradle download failed with HTTP " + status);
            try (InputStream in = connection.getInputStream(); OutputStream out = Files.newOutputStream(destination)) {
                byte[] buffer = new byte[32768];
                int count;
                while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            }
        } finally {
            connection.disconnect();
        }
    }

    private static void extractSafely(Path archive, Path destination) throws IOException {
        Path normalDestination = destination.toAbsolutePath().normalize();
        try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(archive))) {
            ZipEntry entry;
            byte[] buffer = new byte[32768];
            while ((entry = zip.getNextEntry()) != null) {
                Path output = normalDestination.resolve(entry.getName()).normalize();
                if (!output.startsWith(normalDestination)) throw new IOException("Unsafe path in Gradle archive.");
                if (entry.isDirectory()) {
                    Files.createDirectories(output);
                } else {
                    Path parent = output.getParent();
                    if (parent != null) Files.createDirectories(parent);
                    try (OutputStream out = Files.newOutputStream(output)) {
                        int count;
                        while ((count = zip.read(buffer)) != -1) out.write(buffer, 0, count);
                    }
                }
                zip.closeEntry();
            }
        }
    }

    private static void deleteTree(Path root) throws IOException {
        if (!Files.exists(root)) return;
        try (java.util.stream.Stream<Path> paths = Files.walk(root)) {
            paths.sorted(java.util.Comparator.reverseOrder()).forEach(path -> {
                try { Files.deleteIfExists(path); } catch (IOException exception) { throw new RuntimeException(exception); }
            });
        } catch (RuntimeException exception) {
            if (exception.getCause() instanceof IOException) throw (IOException) exception.getCause();
            throw exception;
        }
    }
}
